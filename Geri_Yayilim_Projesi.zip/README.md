# Geri Yayılım Algoritmasının Adım Adım Türetimi

**Hesaplamalı çizge ile görselleştirme ve UCI Wine Quality uygulaması**

Prof. Dr. Hakan Çetinel · Yiğit Apaydın (210301124)  
Manisa Celal Bayar Üniversitesi, Makine Mühendisliği Bölümü

Bu çalışma, geri yayılımı dokuz parametreli bir ağ üzerinde adım adım türetir; aynı hesabı NumPy, PyTorch ve merkezî sonlu farkla karşılaştırır. Gerçek veri uygulamasında kırmızı şarabın kalite puanı, 11 ölçümden tahmin edilir.

## Dosyalar

| İçerik | Konum |
|---|---|
| Akademik bölüm | [PDF](paper/Geri_Yayilim.pdf), [Word](paper/Geri_Yayilim.docx) |
| Kaynakça | [BibTeX](paper/references.bib) |
| Şekiller | [PNG ve PDF dosyaları](paper/figures/) |
| Açıklamalı uygulama | [Notebook](notebooks/backprop_wine.ipynb) |
| NumPy geri yayılımı ve PyTorch referansı | [Kaynak kod](src/backprop_wine/) |
| Deney ve veri ayarları | [Yapılandırmalar](configs/) |
| Ham veri, bölme ve ölçekleyici | [Veri](data/) |
| Kayıtlı eğitim eğrileri ve sonuçlar | [Sonuçlar](results/) |
| Üç ana MLP’nin parametreleri | [Modeller](models/) |

## Kurulum

Python 3.12 kullanın. Doğrulanan ortam Python 3.12.15/macOS arm64’tür; diğer işletim sistemleri ayrıca sınanmadı.

```bash
python -m venv .venv
```

macOS/Linux’ta `source .venv/bin/activate`, Windows PowerShell’de `.venv\Scripts\Activate.ps1` ile ortamı etkinleştirin. Ardından:

```bash
python -m pip install -r requirements.txt
python -m pip install --no-deps -e .
```

## İnceleme ve çalıştırma

```bash
python scripts/demo_backprop.py
python -m pytest -q
python scripts/verify_results.py
python scripts/run_notebook.py
```

İlk komut, küçük ağın ileri değerlerini ve dokuz türevini gösterir. Testler sayısal türevleri, SGD adımlarını, girdi sözleşmelerini ve veri bütünlüğünü denetler. Veri kontrolleri ölçekleyiciyi yalnız eğitim satırlarıyla yeniden hesaplar; Wine modellerini yeniden eğitmez.

`verify_results.py` dosya özetlerini ve kayıtlı metriklerin ortalama/standart sapma hesabını kontrol eder. Notebook yeni Wine modeli eğitmez; test sonuçlarını CSV’den okur. Çalıştırılmış kopya `build/backprop_wine.ipynb` yoluna yazılır.

Teslim ağacında ayrı ortam kurulumu, **120 test**, notebook’un **7 kod hücresi**, küçük ağ örneği ve resmî veri indirme komutu doğrulanmıştır. Gerçek veri modelleri bu kontrol sırasında yeniden eğitilmemiştir.

## Veri ve yöntem

- [UCI Wine Quality veri sayfası](https://archive.ics.uci.edu/dataset/186/wine+quality) · [Resmî ZIP indirme](https://archive.ics.uci.edu/static/public/186/wine%2Bquality.zip) · [Veri DOI’si](https://doi.org/10.24432/C56S3T).
- Kırmızı veri: 1599 satır, 11 girdi; kalite puanı regresyon hedefidir. Beyaz veri ayrı dosyadır ve ana deneyde kullanılmadı.
- Aynı 11 girdiye sahip satırlar birlikte gruplandı. Eğitim/doğrulama/test: **1141/229/229** satır; bölmeler arasında ortak girdi grubu yoktur.
- Bölme seed’i **42**, eğitim seed’leri **42, 43, 44**. StandardScaler yalnız eğitimden öğrenildi.
- Ana ağ: **11–16–1**, tanh gizli katman, doğrusal çıkış, MSE, SGD; öğrenme oranı 0.03, mini-batch 32. En düşük doğrulama kaybının parametreleri saklandı.
- Ayrıntılar: [yöntem notları](docs/METHODS.md), [deney yapılandırması](configs/experiment.json), [veri lisansı](DATA_LICENSE.md).

Ham veriler, bölme satırları, ölçekleyici ve kayıtlı sayısal sonuçlar değiştirilmemiştir. Kaynak kodda teslim için açıklama ve dosya yolları düzenlenmiştir; bu düzenleme, gerçek veri deneyinin yeniden çalıştırıldığı anlamına gelmez. Paket bütünlük listesi, bu depodaki dosyaların özetlerini verir.

## Kayıtlı test sonuçları

Ortak test bölmesi 229 satırdır. Daha düşük RMSE daha iyidir.

| Yöntem | Test RMSE |
|---|---:|
| Eğitim ortalaması | 0.7962 |
| Ridge | 0.6289 |
| Rastgele orman | 0.6250 ± 0.0038 |
| NumPy MLP | 0.6199 ± 0.0070 |
| SVR | **0.5975** |

±, tek sabit bölmedeki üç eğitim seed’inin örneklem standart sapmasıdır; güven aralığı değildir. Bu bölmede SVR daha düşük hata vermiştir. Tek bölme ve üç seed, genel bir yöntem üstünlüğü göstermek için yeterli değildir.

## Ayrı bir deney çalıştırmak

Mevcut sonuçları incelemek için bu adım gerekmez. Aşağıdaki komutlar, yayımlanan **nihai model ayarlarını** yeni bir deney dizininde çalıştırır; hiperparametre aramasını tekrarlamaz. Bu teslim hazırlanırken gerçek veri eğitimi veya test değerlendirmesi yeniden çalıştırılmadı.

```bash
python scripts/train_models.py --output experiments/deneme
python scripts/evaluate_models.py --experiment experiments/deneme
```

Eğitim yalnız eğitim ve doğrulama bölmelerini yükler. Test değerlendirmesi ayrı komuttur ve aynı deney dizininde bir kez çalışır. Çıktılar `results/` ve `models/` altındaki kayıtlı dosyaların üzerine yazılmaz. Yeni deneyler `experiments/` altında tutulur ve Git’e eklenmez.

Veriyi ayrıca indirmek için `python scripts/download_data.py --destination build/veri` kullanılabilir; dosyalar resmî kaynaktan alınır ve kayıtlı üye özetleriyle doğrulanır.
