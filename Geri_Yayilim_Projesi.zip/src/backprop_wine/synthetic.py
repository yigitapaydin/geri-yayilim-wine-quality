"""Synthetic inputs for P2 gradient checks. These are NOT Wine Quality data."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATH = ROOT / 'configs' / 'gradient_check.json'

def load_config(path: Path=CONFIG_PATH) -> dict:
    return json.loads(Path(path).read_text(encoding='utf-8'))

def make_batch(d_in: int, k: int, batch: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((batch, d_in))
    Y = rng.standard_normal((batch, k))
    return (X.astype(np.float64), Y.astype(np.float64))

def case(arch: dict, cfg: dict):
    """Return (params, X, Y) for one architecture entry of the config."""
    from .manual_mlp import init_params
    sizes = arch['sizes']
    params = init_params(sizes, cfg['seeds']['param_init'])
    (X, Y) = make_batch(sizes[0], sizes[-1], arch['batch'], cfg['seeds']['synthetic_data'])
    return (params, X, Y)
