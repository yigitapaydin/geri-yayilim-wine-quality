"""Read-only SHA-256 snapshots and change detection for explicit file lists."""
from __future__ import annotations
import hashlib
from pathlib import Path
FROZEN_FILES = ['configs/experiment.json', 'configs/data_split.json', 'data/raw/manifest.json', 'data/raw/winequality-red.csv', 'data/raw/winequality-white.csv', 'data/raw/winequality.names', 'data/processed/red_rows.csv', 'data/processed/red_scaler_train.json', 'data/processed/red_split_manifest.json', 'src/backprop_wine/manual_mlp.py', 'src/backprop_wine/train.py', 'src/backprop_wine/data.py', 'scripts/train_models.py', 'scripts/evaluate_models.py']

def snapshot(root: Path, files: list[str]=FROZEN_FILES) -> dict:
    out = {}
    for rel in files:
        p = Path(root) / rel
        if not p.exists():
            raise FileNotFoundError(f'frozen file missing: {rel}')
        out[rel] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out

def changed(root: Path, recorded: dict) -> dict:
    """Return {path: (recorded, current)} for every file whose bytes differ (or that is missing) now."""
    diff = {}
    for (rel, h) in recorded.items():
        p = Path(root) / rel
        cur = hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
        if cur != h:
            diff[rel] = (h, cur)
    return diff
