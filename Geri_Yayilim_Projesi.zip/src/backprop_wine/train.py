"""Mini-batch SGD, early stopping and parameter checkpoints for a NumPy MLP. Initialisation and sample order use separate random streams. The final mini-batch is retained. The lowest validation loss checkpoint and patience reference are tracked separately."""
from __future__ import annotations
import hashlib
import math
import time
from dataclasses import dataclass, field
import numpy as np
from . import manual_mlp as mm

def rng_streams(seed: int) -> tuple[int, np.random.Generator]:
    """Return (init_seed for manual_mlp.init_params, shuffle generator) for one training seed."""
    (init_ss, shuffle_ss) = np.random.SeedSequence(seed).spawn(2)
    init_seed = int(init_ss.generate_state(1, dtype=np.uint32)[0])
    return (init_seed, np.random.default_rng(shuffle_ss))

def minibatch_indices(order: np.ndarray, batch_size: int) -> list[np.ndarray]:
    """Consecutive slices of a permutation; the last (possibly smaller) batch is kept."""
    return [order[i:i + batch_size] for i in range(0, len(order), batch_size)]

class EarlyStopper:
    """Absolute-best checkpoint tracking and min_delta patience, kept as two separate quantities."""

    def __init__(self, patience: int, min_delta: float):
        (self.patience, self.min_delta) = (patience, min_delta)
        self.best_val = math.inf
        self.best_epoch = None
        self.reference = math.inf
        self.wait = 0

    def update(self, epoch: int, val: float) -> tuple[bool, bool]:
        """Return (is_new_absolute_best, should_stop)."""
        new_best = val < self.best_val
        if new_best:
            (self.best_val, self.best_epoch) = (val, epoch)
        if val < self.reference - self.min_delta:
            (self.reference, self.wait) = (val, 0)
        else:
            self.wait += 1
        return (new_best, self.wait >= self.patience)

def check_xy(X, Y, n_inputs: int, n_outputs: int, name: str) -> None:
    """Shape contract for one split: X (n, n_inputs), Y (n, n_outputs), both 2-D float64, n > 0.
    Values are NOT checked for finiteness here: non-finite data keep the existing 'diverged' contract of train_mlp."""
    for (part, A) in (('X', X), ('Y', Y)):
        if not isinstance(A, np.ndarray) or A.dtype != np.float64 or A.ndim != 2:
            raise TypeError(f'{name} {part} must be a 2-D float64 array')
    if X.shape[0] == 0:
        raise ValueError(f'{name} split is empty')
    if X.shape[1] != n_inputs:
        raise ValueError(f'{name} X has {X.shape[1]} columns, the network expects {n_inputs}')
    if Y.shape != (X.shape[0], n_outputs):
        raise ValueError(f'{name} Y must have shape {(X.shape[0], n_outputs)}, got {Y.shape}')

def _mse(params, X, Y, act) -> float:
    (Yhat, _) = mm.forward(params, X, act)
    return mm.mse_loss(Yhat, Y)

def _grad_norms(params, X, Y, act) -> dict:
    (_, g) = mm.loss_and_grads(params, X, Y, act)
    out = {}
    for (l, gl) in enumerate(g, start=1):
        out[f'gradnorm_W{l}'] = float(np.linalg.norm(gl['W']))
        out[f'gradnorm_b{l}'] = float(np.linalg.norm(gl['b']))
    return out

def activation_diagnostics(params, X) -> dict:
    """First-hidden-layer diagnostics: tanh saturation, nonpositive ReLU cells and units nonpositive for every training sample."""
    Z1 = X @ params[0]['W'] + params[0]['b']
    return {'tanh_saturation_frac': float(np.mean(np.abs(Z1) > 3.0)), 'relu_passive_frac': float(np.mean(Z1 <= 0)), 'relu_dead_unit_frac': float(np.mean(np.all(Z1 <= 0, axis=0)))}

def params_digest(params) -> str:
    h = hashlib.sha256()
    for p in params:
        h.update(np.ascontiguousarray(p['W']).tobytes())
        h.update(np.ascontiguousarray(p['b']).tobytes())
    return h.hexdigest()

@dataclass
class TrainResult:
    status: str
    history: list = field(default_factory=list)
    best_params: list | None = None
    best_epoch: int | None = None
    best_val_mse: float | None = None
    stopped_epoch: int | None = None
    divergence: dict | None = None
    init_digest: str = ''
    batch_order_digest: str = ''
    first_epoch_order_digest: str = ''
    first_epochs_order_digests: list = field(default_factory=list)
    shuffle_state_end: str = ''

def train_mlp(Xtr, Ytr, Xva, Yva, *, sizes, hidden_activation, lr, batch_size, max_epochs, patience, min_delta, seed) -> TrainResult:
    check_xy(Xtr, Ytr, sizes[0], sizes[-1], 'train')
    check_xy(Xva, Yva, sizes[0], sizes[-1], 'validation')
    (init_seed, shuf) = rng_streams(seed)
    params = mm.init_params(sizes, seed=init_seed)
    res = TrainResult(status='running', init_digest=params_digest(params))
    order_hash = hashlib.sha256()
    stopper = EarlyStopper(patience, min_delta)
    n = Xtr.shape[0]

    def record(epoch, seconds, n_updates):
        (tr, va) = (_mse(params, Xtr, Ytr, hidden_activation), _mse(params, Xva, Yva, hidden_activation))
        row = {'epoch': epoch, 'train_mse': tr, 'train_rmse': math.sqrt(tr) if tr >= 0 else math.nan, 'val_mse': va, 'val_rmse': math.sqrt(va) if va >= 0 else math.nan, **_grad_norms(params, Xtr, Ytr, hidden_activation), **activation_diagnostics(params, Xtr), 'seconds': seconds, 'n_updates': n_updates}
        res.history.append(row)
        return (tr, va)
    with np.errstate(over='ignore', invalid='ignore'):
        (tr, va) = record(0, 0.0, 0)
        if not (math.isfinite(tr) and math.isfinite(va)):
            (res.status, res.stopped_epoch) = ('diverged', 0)
            res.divergence = {'epoch': 0, 'step': None, 'where': 'initial metrics'}
            return res
        stopper.update(0, va)
        (res.best_params, res.best_epoch, res.best_val_mse) = (mm.copy_params(params), 0, va)
        n_updates = 0
        for epoch in range(1, max_epochs + 1):
            t0 = time.perf_counter()
            order = shuf.permutation(n)
            order_hash.update(order.astype(np.int64).tobytes())
            if epoch <= 5:
                dg = hashlib.sha256(order.astype(np.int64).tobytes()).hexdigest()
                res.first_epochs_order_digests.append(dg)
                if epoch == 1:
                    res.first_epoch_order_digest = dg
            for (step, idx) in enumerate(minibatch_indices(order, batch_size)):
                (loss, g) = mm.loss_and_grads(params, Xtr[idx], Ytr[idx], hidden_activation)
                if not math.isfinite(loss) or not all((np.isfinite(gl['W']).all() and np.isfinite(gl['b']).all() for gl in g)):
                    (res.status, res.stopped_epoch) = ('diverged', epoch)
                    res.divergence = {'epoch': epoch, 'step': step, 'where': 'mini-batch loss/gradient', 'loss': loss}
                    break
                params = mm.sgd_step(params, g, lr)
                n_updates += 1
            if res.status == 'diverged':
                break
            (tr, va) = record(epoch, time.perf_counter() - t0, n_updates)
            if not (math.isfinite(tr) and math.isfinite(va)):
                (res.status, res.stopped_epoch) = ('diverged', epoch)
                res.divergence = {'epoch': epoch, 'step': None, 'where': 'epoch metrics'}
                break
            (new_best, stop) = stopper.update(epoch, va)
            if new_best:
                (res.best_params, res.best_epoch, res.best_val_mse) = (mm.copy_params(params), epoch, va)
            if stop:
                (res.status, res.stopped_epoch) = ('early_stopped', epoch)
                break
        else:
            (res.status, res.stopped_epoch) = ('max_epochs', max_epochs)
    res.batch_order_digest = order_hash.hexdigest()
    res.shuffle_state_end = hashlib.sha256(repr(shuf.bit_generator.state).encode()).hexdigest()
    return res

def _single_output_vector(a, name: str) -> np.ndarray:
    a = np.asarray(a, dtype=np.float64)
    if not (a.ndim == 1 or (a.ndim == 2 and a.shape[1] == 1)):
        raise ValueError(f'{name} must have shape (n,) or (n, 1) for single-output regression, got {a.shape}')
    return a.ravel()

def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """RMSE, MAE and R² for one output. Inputs must be nonempty finite vectors with equal lengths, represented as (n,) or (n, 1)."""
    y_true = _single_output_vector(y_true, 'y_true')
    y_pred = _single_output_vector(y_pred, 'y_pred')
    if y_true.size == 0:
        raise ValueError('regression_metrics needs at least one observation')
    if y_true.size != y_pred.size:
        raise ValueError(f'y_true has {y_true.size} values but y_pred has {y_pred.size}')
    if not (np.isfinite(y_true).all() and np.isfinite(y_pred).all()):
        raise ValueError('regression_metrics received non-finite values')
    err = y_pred - y_true
    ss_res = float(np.sum(err ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    return {'rmse': math.sqrt(float(np.mean(err ** 2))), 'mae': float(np.mean(np.abs(err))), 'r2': 1.0 - ss_res / ss_tot if ss_tot > 0 else math.nan, 'n': int(y_true.size)}

def save_checkpoint(path, params) -> str:
    """Save parameter arrays W1, b1, ... and return the file SHA-256."""
    arrays = {}
    for (l, p) in enumerate(params, start=1):
        (arrays[f'W{l}'], arrays[f'b{l}']) = (p['W'], p['b'])
    np.savez(path, **arrays)
    with open(path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()

def load_checkpoint(path) -> list:
    with np.load(path) as z:
        L = len([k for k in z.files if k.startswith('W')])
        return [{'W': z[f'W{l}'].copy(), 'b': z[f'b{l}'].copy()} for l in range(1, L + 1)]

def torch_trajectory_check(Xtr, Ytr, Xva, Yva, *, sizes, hidden_activation, lr, batch_size, n_epochs, seed, atol, rtol) -> dict:
    """Compare NumPy backpropagation and PyTorch SGD from identical initial parameters and mini-batches. Check every parameter and training/validation loss after every epoch."""
    import torch
    from .torch_reference import build_model, model_to_params
    check_xy(Xtr, Ytr, sizes[0], sizes[-1], 'train')
    check_xy(Xva, Yva, sizes[0], sizes[-1], 'validation')
    (init_seed, shuf) = rng_streams(seed)
    p_np = mm.init_params(sizes, seed=init_seed)
    model = build_model(p_np, hidden_activation)
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.0, weight_decay=0.0)
    (Xt_tr, Yt_tr) = (torch.from_numpy(Xtr), torch.from_numpy(Ytr))
    (per_epoch, ok_all, max_param_diff, max_metric_diff) = ([], True, 0.0, 0.0)
    torch_val = []

    def compare(epoch):
        p_t = model_to_params(model)
        (diffs, ok) = ([], True)
        for (a, r) in zip(p_np, p_t):
            for k in ('W', 'b'):
                d = np.abs(a[k] - r[k])
                diffs.append(float(d.max()))
                ok &= bool(np.all(d <= atol + rtol * np.abs(r[k])))
        with torch.no_grad():
            tr_t = float(torch.mean((model(Xt_tr) - Yt_tr) ** 2))
            va_t = float(torch.mean((model(torch.from_numpy(Xva)) - torch.from_numpy(Yva)) ** 2))
        (tr_n, va_n) = (_mse(p_np, Xtr, Ytr, hidden_activation), _mse(p_np, Xva, Yva, hidden_activation))
        md = max(abs(tr_n - tr_t), abs(va_n - va_t))
        ok &= abs(tr_n - tr_t) <= atol + rtol * abs(tr_t) and abs(va_n - va_t) <= atol + rtol * abs(va_t)
        return {'epoch': epoch, 'max_abs_param_diff': max(diffs), 'max_abs_metric_diff': md, 'numpy_train_mse': tr_n, 'torch_train_mse': tr_t, 'numpy_val_mse': va_n, 'torch_val_mse': va_t, 'within_tolerance': bool(ok)}
    e0 = compare(0)
    per_epoch.append(e0)
    ok_all &= e0['within_tolerance']
    (max_param_diff, max_metric_diff) = (e0['max_abs_param_diff'], e0['max_abs_metric_diff'])
    for epoch in range(1, n_epochs + 1):
        order = shuf.permutation(Xtr.shape[0])
        for idx in minibatch_indices(order, batch_size):
            (_, g) = mm.loss_and_grads(p_np, Xtr[idx], Ytr[idx], hidden_activation)
            p_np = mm.sgd_step(p_np, g, lr)
            ti = torch.from_numpy(idx)
            opt.zero_grad(set_to_none=True)
            torch.nn.MSELoss(reduction='mean')(model(Xt_tr[ti]), Yt_tr[ti]).backward()
            opt.step()
        row = compare(epoch)
        ok_all &= row['within_tolerance']
        max_param_diff = max(max_param_diff, row['max_abs_param_diff'])
        max_metric_diff = max(max_metric_diff, row['max_abs_metric_diff'])
        torch_val.append(row['torch_val_mse'])
        per_epoch.append(row)
    return {'passed': bool(ok_all), 'atol': atol, 'rtol': rtol, 'n_epochs': n_epochs, 'max_abs_param_diff': max_param_diff, 'max_abs_metric_diff': max_metric_diff, 'numpy_final_val_mse': per_epoch[-1]['numpy_val_mse'], 'torch_val_mse_epoch0': e0['torch_val_mse'], 'torch_val_mse_by_epoch': torch_val, 'per_epoch': per_epoch}

def aggregate_runs(rows: list[dict], completed_statuses, prefixes=('val_', 'train_', 'test_'), required_metrics=None) -> list[dict]:
    """Aggregate completed runs by their fixed aggregation_group. Validate required finite metrics, then report means and sample standard deviations (ddof=1)."""
    groups: dict = {}
    for r in rows:
        if r.get('aggregation_group'):
            groups.setdefault(r['aggregation_group'], []).append(r)
    out = []
    for (g, xs) in groups.items():
        seeds = [x['seed'] for x in xs]
        if len(seeds) != len(set(seeds)):
            raise ValueError(f'duplicate seed in aggregation group {g}: {seeds}')
        ok = [x for x in xs if x['status'] in completed_statuses]
        row = {'aggregation_group': g, 'seeds': ';'.join((str(s) for s in sorted(seeds))), 'n_planned': len(xs), 'n_completed': len(ok), 'n_diverged': sum((x['status'] == 'diverged' for x in xs)), 'statuses': ';'.join(sorted({x['status'] for x in xs})), 'aggregate_note': '' if len(ok) == len(xs) else 'PARTIAL: mean/std over completed runs only; failed runs are reported, not averaged or replaced'}
        if required_metrics is not None:
            keys = list(required_metrics)
        else:
            keys = list(dict.fromkeys((c for x in xs for c in x if c.startswith(tuple(prefixes)))))
        for k in keys:
            for x in ok:
                val = x.get(k)
                if val is None or isinstance(val, bool) or (not isinstance(val, (int, float, np.floating, np.integer))) or (not math.isfinite(float(val))):
                    raise ValueError(f"group {g}: completed run seed={x.get('seed')} has missing or non-finite {k}={val!r}")
        for k in keys:
            v = np.array([x[k] for x in ok], dtype=float)
            row[f'{k}_mean'] = float(v.mean()) if v.size else None
            row[f'{k}_std_ddof1'] = float(v.std(ddof=1)) if v.size > 1 else None
        out.append(row)
    return out
