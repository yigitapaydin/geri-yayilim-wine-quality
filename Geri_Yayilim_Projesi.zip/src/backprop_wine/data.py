"""UCI Wine Quality: strict parsing, input-only grouping, leakage-free group split, train-only scaling.

All functions are deterministic. The raw files in data/raw are only read, never modified.
"""
from __future__ import annotations
import csv
import hashlib
import json
import math
import warnings
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
RAW_DIR = ROOT / 'data' / 'raw'
CONFIG_PATH = ROOT / 'configs' / 'data_split.json'
PROCESSED_DIR = ROOT / 'data' / 'processed'

class DataIntegrityError(RuntimeError):
    """Raised when raw data, schema, config or saved split/scaler records do not match."""
FEATURES = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']
TARGET = 'quality'
SUBSET_FILES = {'red': 'winequality-red.csv', 'white': 'winequality-white.csv'}

def load_config(path: Path=CONFIG_PATH) -> dict:
    return json.loads(Path(path).read_text(encoding='utf-8'))

def sha256_file(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_wine_csv(path: Path, delimiter: str=';') -> dict:
    """Strict reader. Every data line must have 12 fields that parse as finite floats and an integral target.
    Bad lines are counted and excluded from the arrays (never silently repaired)."""
    raw = Path(path).read_bytes()
    text = raw.decode('ascii')
    report = {'file': Path(path).name, 'sha256': hashlib.sha256(raw).hexdigest(), 'n_bytes': len(raw), 'has_crlf': '\r\n' in text, 'ends_with_newline': text.endswith('\n'), 'n_wrong_field_count': 0, 'n_unparseable': 0, 'n_nan': 0, 'n_inf': 0, 'n_non_integer_target': 0, 'n_blank_lines': 0, 'bad_lines': []}
    rows = list(csv.reader(text.splitlines(), delimiter=delimiter, quotechar='"'))
    header = rows[0]
    report['header'] = header
    report['header_matches_expected'] = header == FEATURES + [TARGET]
    (X, y, line_numbers, raw_fields) = ([], [], [], [])
    for (ln, fields) in enumerate(rows[1:], start=2):
        if not fields:
            report['n_blank_lines'] += 1
            continue
        if len(fields) != 12:
            report['n_wrong_field_count'] += 1
            report['bad_lines'].append(ln)
            continue
        try:
            vals = [float(f) for f in fields]
        except ValueError:
            report['n_unparseable'] += 1
            report['bad_lines'].append(ln)
            continue
        if any((math.isnan(v) for v in vals)):
            report['n_nan'] += 1
            report['bad_lines'].append(ln)
            continue
        if any((math.isinf(v) for v in vals)):
            report['n_inf'] += 1
            report['bad_lines'].append(ln)
            continue
        if vals[11] != int(vals[11]):
            report['n_non_integer_target'] += 1
            report['bad_lines'].append(ln)
            continue
        X.append(vals[:11])
        y.append(int(vals[11]))
        line_numbers.append(ln)
        raw_fields.append(fields[:11])
    report['n_data_lines'] = len(rows) - 1
    report['n_rows_parsed'] = len(X)
    return {'X': np.array(X, dtype=np.float64), 'y': np.array(y, dtype=np.int64), 'line_numbers': np.array(line_numbers), 'raw_fields': raw_fields, 'header': header, 'report': report}

def read_wine_csv_strict(path: Path, delimiter: str=';', expected_rows: int | None=None) -> dict:
    """Modelling-time reader: any header mismatch, rejected or blank line is a hard error (no silent dropping)."""
    d = read_wine_csv(path, delimiter)
    r = d['report']
    if not r['header_matches_expected']:
        raise DataIntegrityError(f"{r['file']}: header {r['header']} != expected {FEATURES + [TARGET]}")
    if r['bad_lines'] or r['n_blank_lines']:
        raise DataIntegrityError(f"{r['file']}: rejected lines {r['bad_lines']} / blank lines {r['n_blank_lines']}")
    if r['n_rows_parsed'] != r['n_data_lines']:
        raise DataIntegrityError(f"{r['file']}: parsed {r['n_rows_parsed']} of {r['n_data_lines']} lines")
    if expected_rows is not None and r['n_rows_parsed'] != expected_rows:
        raise DataIntegrityError(f"{r['file']}: {r['n_rows_parsed']} rows, expected {expected_rows}")
    return d

def verify_raw_manifest(raw_dir: Path=RAW_DIR) -> dict:
    """Every member listed in data/raw/manifest.json must exist with the recorded SHA-256."""
    m = json.loads((Path(raw_dir) / 'manifest.json').read_text(encoding='utf-8'))
    for mem in m['members']:
        p = Path(raw_dir) / mem['name']
        if not p.exists():
            raise DataIntegrityError(f"raw file missing: {mem['name']}")
        if sha256_file(p) != mem['sha256']:
            raise DataIntegrityError(f"raw file {mem['name']} sha256 {sha256_file(p)} != manifest {mem['sha256']}")
    return m

def verify_provenance(raw_dir: Path=RAW_DIR) -> dict:
    """Verify the recorded source ZIP, dataset-card snapshot and extracted members against their SHA-256 values."""
    raw_dir = Path(raw_dir)
    m = verify_raw_manifest(raw_dir)
    chain = {step['step']: step for step in m['provenance_chain']}
    zip_step = chain['ZIP']
    zip_path = raw_dir / Path(zip_step['file']).name
    if not zip_path.exists():
        raise DataIntegrityError(f'provenance ZIP missing: {zip_path.name}')
    if sha256_file(zip_path) != zip_step['sha256']:
        raise DataIntegrityError('provenance ZIP sha256 does not match manifest')
    card = chain['UCI dataset card']
    snap = raw_dir / 'provenance' / Path(card['checks']['snapshot_file']).name
    if not snap.exists():
        raise DataIntegrityError(f'dataset-card snapshot missing: {snap.name}')
    if sha256_file(snap) != card['sha256']:
        raise DataIntegrityError('dataset-card snapshot sha256 does not match manifest')
    import zipfile
    with zipfile.ZipFile(zip_path) as zf:
        for mem in m['members']:
            if hashlib.sha256(zf.read(mem['name'])).hexdigest() != mem['sha256']:
                raise DataIntegrityError(f"ZIP member {mem['name']} differs from the extracted file")
    return {'zip_sha256': zip_step['sha256'], 'card_snapshot_sha256': card['sha256'], 'members': {x['name']: x['sha256'] for x in m['members']}}

def row_ids(subset: str, n: int) -> list[str]:
    """Immutable row id = subset + 0-based data-row index in the original CSV (= file line - 2)."""
    return [f'{subset}_{i:05d}' for i in range(n)]

def group_key(x_row) -> str:
    """Canonical key from the eleven input values only. Positive and negative zero share one representation; the target is never included."""
    if len(x_row) != 11:
        raise ValueError('group key needs exactly the 11 input values')
    return '|'.join((repr(float(v) + 0.0) for v in x_row))

def assign_groups(X: np.ndarray) -> tuple[np.ndarray, list[str]]:
    """Integer group id in order of first occurrence, plus the canonical key of every row."""
    keys = [group_key(r) for r in X]
    first: dict[str, int] = {}
    gid = np.empty(len(keys), dtype=np.int64)
    for (i, k) in enumerate(keys):
        gid[i] = first.setdefault(k, len(first))
    return (gid, keys)

def duplicate_stats(X: np.ndarray, y: np.ndarray, gid: np.ndarray) -> dict:
    n = len(y)
    sizes = np.bincount(gid)
    multi = np.where(sizes > 1)[0]
    full_seen: set = set()
    n_full_dup_extra = 0
    for i in range(n):
        k = (group_key(X[i]), int(y[i]))
        if k in full_seen:
            n_full_dup_extra += 1
        full_seen.add(k)
    conflicting = [g for g in multi if len(set(y[gid == g].tolist())) > 1]
    sse = 0.0
    for g in multi:
        yg = y[gid == g].astype(np.float64)
        sse += float(((yg - yg.mean()) ** 2).sum())
    size_hist = {int(s): int((sizes == s).sum()) for s in sorted(set(sizes.tolist()))}
    return {'n_rows': int(n), 'n_unique_input_vectors': int(len(sizes)), 'n_groups_with_more_than_one_row': int(len(multi)), 'n_rows_in_multi_row_groups': int(sizes[multi].sum()) if len(multi) else 0, 'group_size_histogram': size_hist, 'n_unique_full_rows_inputs_plus_target': int(len(full_seen)), 'n_full_row_duplicates_beyond_first': int(n_full_dup_extra), 'n_conflicting_label_groups': int(len(conflicting)), 'n_rows_in_conflicting_label_groups': int(sum((int(sizes[g]) for g in conflicting))), 'conflicting_groups_quality_sets': [sorted(set(y[gid == g].tolist())) for g in conflicting], 'empirical_identical_input_mse_floor': sse / n, 'empirical_floor_note': 'Mean squared deviation from the per-group mean over ALL rows of this table. It is a lower bound for any function of the 11 inputs ON THESE OBSERVED ROWS only; not a Bayes or population irreducible error.'}

def make_split(y: np.ndarray, gid: np.ndarray, split_cfg: dict) -> tuple[np.ndarray, list[str]]:
    """Return per-row split labels ('train'/'validation'/'test') and any sklearn warnings raised."""
    from sklearn.model_selection import StratifiedGroupKFold
    if split_cfg['method'] != 'sklearn.model_selection.StratifiedGroupKFold':
        raise ValueError(split_cfg['method'])
    sgkf = StratifiedGroupKFold(n_splits=split_cfg['n_splits'], shuffle=split_cfg['shuffle'], random_state=split_cfg['random_state'])
    fold_of = np.full(len(y), -1, dtype=np.int64)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        for (f, (_, test_idx)) in enumerate(sgkf.split(np.zeros((len(y), 1)), y, groups=gid)):
            fold_of[test_idx] = f
    if (fold_of < 0).any():
        raise RuntimeError('some rows were not assigned to any fold')
    label = np.empty(len(y), dtype=object)
    for (name, folds) in split_cfg['fold_assignment'].items():
        label[np.isin(fold_of, folds)] = name
    if any((v is None for v in label)):
        raise RuntimeError('fold_assignment does not cover every fold')
    return (label.astype(str), [str(w.message) for w in caught])

def fit_scaler(X_train: np.ndarray):
    from sklearn.preprocessing import StandardScaler
    return StandardScaler(with_mean=True, with_std=True).fit(X_train)

def scaler_record(scaler, fit_row_ids: list[str]) -> dict:
    import sklearn
    ids_blob = '\n'.join(fit_row_ids).encode()
    return {'class': 'sklearn.preprocessing.StandardScaler', 'sklearn_version': sklearn.__version__, 'features': FEATURES, 'mean': scaler.mean_.tolist(), 'scale': scaler.scale_.tolist(), 'var': scaler.var_.tolist(), 'n_samples_seen': int(scaler.n_samples_seen_), 'fit_split': 'train', 'fit_row_count': len(fit_row_ids), 'fit_row_ids_sha256': hashlib.sha256(ids_blob).hexdigest(), 'std_definition': 'population std (ddof=0), as in sklearn StandardScaler'}

def build_red(raw_dir: Path=RAW_DIR, cfg: dict | None=None, verify_raw: bool=True) -> dict:
    """Deterministic red pipeline. Verifies raw hashes and strict schema first (hard errors, no dropping)."""
    cfg = cfg or load_config()
    if verify_raw:
        verify_raw_manifest(raw_dir)
    d = read_wine_csv_strict(Path(raw_dir) / SUBSET_FILES['red'], cfg['parsing']['delimiter'])
    (X, y) = (d['X'], d['y'])
    ids = row_ids('red', len(y))
    (gid, keys) = assign_groups(X)
    (split, warns) = make_split(y, gid, cfg['split'])
    train = split == 'train'
    scaler = fit_scaler(X[train])
    return {'X': X, 'y': y, 'row_ids': ids, 'group_id': gid, 'group_key': keys, 'split': split, 'split_warnings': warns, 'scaler': scaler, 'parse_report': d['report'], 'line_numbers': d['line_numbers']}
RECORD_FILES = ('red_rows.csv', 'red_scaler_train.json')

def load_processed(processed_dir: Path=PROCESSED_DIR, raw_dir: Path=RAW_DIR, config_path: Path=CONFIG_PATH, splits: tuple=('train', 'validation', 'test')) -> dict:
    """Modelling loader for P6. Hard-fails (DataIntegrityError) unless ALL of the following hold:
    1. every raw file matches data/raw/manifest.json;
    2. the red CSV passes the strict schema (exact header, 12 finite fields, integral target, no dropped line);
    3. the config file is byte-identical to the one recorded in the split manifest;
    4. the saved record files match the SHA-256 values in the split manifest;
    5. per row: row id, CSV line, quality, group id, group-key hash and split equal a fresh recomputation
       from the raw data and the config (so editing a label or a split cell cannot pass silently);
    6. the saved scaler equals a fresh train-only fit (mean, scale, var, n_samples_seen, fit-row hash).
    """
    P = Path(processed_dir)
    raw_manifest = verify_raw_manifest(raw_dir)
    sm = json.loads((P / 'red_split_manifest.json').read_text(encoding='utf-8'))
    if sha256_file(config_path) != sm.get('config_sha256'):
        raise DataIntegrityError('config file differs from the one used to build the saved split')
    raw_red = {m['name']: m['sha256'] for m in raw_manifest['members']}['winequality-red.csv']
    if sm.get('raw_red_sha256') != raw_red:
        raise DataIntegrityError('split manifest was built from a different red CSV')
    for fname in RECORD_FILES:
        if sha256_file(P / fname) != sm.get('file_sha256', {}).get(fname):
            raise DataIntegrityError(f'record file {fname} does not match its recorded SHA-256')
    cfg = load_config(config_path)
    R = build_red(raw_dir, cfg, verify_raw=False)
    if len(R['y']) != sm['n_rows']:
        raise DataIntegrityError(f"raw red rows {len(R['y'])} != recorded {sm['n_rows']}")
    with open(P / 'red_rows.csv', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    if len(rows) != len(R['y']):
        raise DataIntegrityError('red_rows.csv row count differs from the raw file')
    key_sha = [hashlib.sha256(k.encode()).hexdigest()[:16] for k in R['group_key']]
    for (i, r) in enumerate(rows):
        expect = {'row_id': R['row_ids'][i], 'csv_line': str(int(R['line_numbers'][i])), 'group_id': str(int(R['group_id'][i])), 'group_key_sha16': key_sha[i], 'split': str(R['split'][i]), 'quality': str(int(R['y'][i]))}
        bad = {k: (r.get(k), v) for (k, v) in expect.items() if r.get(k) != v}
        if bad:
            raise DataIntegrityError(f'red_rows.csv line {i + 2} does not match recomputation: {bad}')
    sc = json.loads((P / 'red_scaler_train.json').read_text(encoding='utf-8'))
    fresh = scaler_record(R['scaler'], [i for (i, s) in zip(R['row_ids'], R['split']) if s == 'train'])
    for k in ('mean', 'scale', 'var'):
        if not np.allclose(sc[k], fresh[k], rtol=1e-12, atol=0):
            raise DataIntegrityError(f"saved scaler '{k}' is not the train-only fit")
    for k in ('n_samples_seen', 'fit_row_ids_sha256', 'fit_split', 'features'):
        if sc[k] != fresh[k]:
            raise DataIntegrityError(f"saved scaler '{k}' mismatch")
    (mean, scale) = (np.array(sc['mean']), np.array(sc['scale']))
    if not set(splits) <= {'train', 'validation', 'test'}:
        raise ValueError(f'unknown split names {splits}')
    out = {'scaler': sc, 'config_version': cfg.get('version'), 'splits_loaded': list(splits)}
    if 'test' in splits:
        out['split'] = R['split']
    for name in splits:
        m = R['split'] == name
        out[name] = {'X_raw': R['X'][m], 'X': (R['X'][m] - mean) / scale, 'y': R['y'][m].astype(np.float64), 'row_ids': [i for (i, k) in zip(R['row_ids'], m) if k], 'group_id': R['group_id'][m].copy(), 'csv_line': R['line_numbers'][m].copy()}
    return out
