"""Central finite differences and tolerance comparison utilities."""
from __future__ import annotations
from typing import Callable
import numpy as np

def central_difference(loss_fn: Callable[[list], float], params: list, h: float) -> list:
    """dL/dtheta_k ~ (L(theta + h e_k) - L(theta - h e_k)) / (2h) for EVERY scalar parameter.

    Works on private copies; the caller's arrays are never modified.
    """
    work = [{'W': p['W'].copy(), 'b': p['b'].copy()} for p in params]
    out = [{'W': np.zeros_like(p['W']), 'b': np.zeros_like(p['b'])} for p in params]
    for (l, p) in enumerate(work):
        for key in ('W', 'b'):
            arr = p[key]
            it = np.nditer(arr, flags=['multi_index'])
            for _ in it:
                idx = it.multi_index
                orig = arr[idx]
                arr[idx] = orig + h
                lp = loss_fn(work)
                arr[idx] = orig - h
                lm = loss_fn(work)
                arr[idx] = orig
                out[l][key][idx] = (lp - lm) / (2.0 * h)
    return out

def compare_arrays(a: np.ndarray, ref: np.ndarray, atol: float, rtol: float) -> dict:
    """Element-wise |a - ref| <= atol + rtol * |ref|. Also returns diagnostic error statistics."""
    a = np.asarray(a, dtype=np.float64)
    ref = np.asarray(ref, dtype=np.float64)
    if a.shape != ref.shape:
        return {'passed': False, 'reason': f'shape mismatch {a.shape} vs {ref.shape}'}
    abs_err = np.abs(a - ref)
    bound = atol + rtol * np.abs(ref)
    denom = np.maximum(np.abs(ref), np.finfo(np.float64).tiny)
    rel_err = abs_err / denom
    ratio = np.divide(abs_err, bound, out=np.where(abs_err > 0, np.inf, 0.0), where=bound > 0)
    worst = int(np.argmax(ratio)) if abs_err.size else 0
    return {'passed': bool(np.all(abs_err <= bound)), 'n': int(abs_err.size), 'n_failed': int(np.sum(abs_err > bound)), 'max_abs_err': float(abs_err.max()) if abs_err.size else 0.0, 'max_rel_err': float(rel_err.max()) if abs_err.size else 0.0, 'max_err_over_bound': float(ratio.max()) if abs_err.size else 0.0, 'worst_flat_index': worst}

def compare_params(a: list, ref: list, atol: float, rtol: float) -> dict:
    per = {}
    for (l, (pa, pr)) in enumerate(zip(a, ref), start=1):
        for key in ('W', 'b'):
            per[f'{key}{l}'] = compare_arrays(pa[key], pr[key], atol, rtol)
    flat_a = np.concatenate([np.concatenate([p['W'].ravel(), p['b'].ravel()]) for p in a])
    flat_r = np.concatenate([np.concatenate([p['W'].ravel(), p['b'].ravel()]) for p in ref])
    overall = compare_arrays(flat_a, flat_r, atol, rtol) if flat_a.shape == flat_r.shape else {'passed': False, 'reason': 'parameter count mismatch'}
    overall['passed'] = overall['passed'] and len(a) == len(ref) and all((v['passed'] for v in per.values()))
    return {'overall': overall, 'per_param': per, 'atol': atol, 'rtol': rtol}
