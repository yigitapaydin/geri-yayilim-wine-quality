"""Multi-layer perceptron with hand-written backpropagation (NumPy only, no autograd).

Shapes (rows are samples):
    X      : B x d_0
    W_l    : d_(l-1) x d_l
    b_l    : 1 x d_l
    Z_l    = A_(l-1) W_l + b_l          (B x d_l)
    A_l    = g(Z_l) for hidden layers, A_L = Z_L for the linear output layer
    L      = (1 / (B k)) * sum_{i,j} (A_L - Y)_{ij}^2,   Y: B x k

Backward pass:
    dZ_L     = 2 (A_L - Y) / (B k)
    dW_l     = A_(l-1)^T dZ_l
    db_l     = sum over the batch rows of dZ_l
    dA_(l-1) = dZ_l W_l^T
    dZ_(l-1) = dA_(l-1) * g'(Z_(l-1))

ReLU convention: g'(0) is taken as 0 (the same choice PyTorch makes; this is a
convention, ReLU is not differentiable at 0).
"""
from __future__ import annotations
import numpy as np
Params = list[dict[str, np.ndarray]]

def _tanh(z: np.ndarray) -> np.ndarray:
    return np.tanh(z)

def _tanh_grad(z: np.ndarray, a: np.ndarray) -> np.ndarray:
    return 1.0 - a * a

def _relu(z: np.ndarray) -> np.ndarray:
    return np.maximum(z, 0.0)

def _relu_grad(z: np.ndarray, a: np.ndarray) -> np.ndarray:
    return (z > 0.0).astype(z.dtype)
ACTIVATIONS = {'tanh': (_tanh, _tanh_grad), 'relu': (_relu, _relu_grad)}

def init_params(sizes: list[int], seed: int) -> Params:
    """Glorot-uniform weights and small non-zero biases (non-zero so bias paths are tested)."""
    if len(sizes) < 2:
        raise ValueError('need at least input and output sizes')
    rng = np.random.default_rng(seed)
    params: Params = []
    for (d_in, d_out) in zip(sizes[:-1], sizes[1:]):
        limit = np.sqrt(6.0 / (d_in + d_out))
        W = rng.uniform(-limit, limit, size=(d_in, d_out)).astype(np.float64)
        b = rng.uniform(-0.1, 0.1, size=(1, d_out)).astype(np.float64)
        params.append({'W': W, 'b': b})
    return params

def copy_params(params: Params) -> Params:
    return [{'W': p['W'].copy(), 'b': p['b'].copy()} for p in params]

def param_names(params: Params) -> list[str]:
    names = []
    for (l, _) in enumerate(params, start=1):
        names += [f'W{l}', f'b{l}']
    return names

def flatten(params: Params) -> np.ndarray:
    return np.concatenate([np.concatenate([p['W'].ravel(), p['b'].ravel()]) for p in params])

def _check_inputs(params: Params, X: np.ndarray, Y: np.ndarray | None=None) -> None:
    if X.ndim != 2:
        raise ValueError(f'X must be 2-D (B x d), got shape {X.shape}')
    if X.dtype != np.float64:
        raise TypeError(f'X must be float64, got {X.dtype}')
    if X.shape[1] != params[0]['W'].shape[0]:
        raise ValueError('X columns do not match the first weight matrix')
    for (l, p) in enumerate(params):
        if p['W'].dtype != np.float64 or p['b'].dtype != np.float64:
            raise TypeError(f'layer {l + 1} parameters must be float64')
        if p['b'].shape != (1, p['W'].shape[1]):
            raise ValueError(f"b{l + 1} must have shape (1, {p['W'].shape[1]}), got {p['b'].shape}")
    if Y is not None:
        k = params[-1]['W'].shape[1]
        if Y.shape != (X.shape[0], k):
            raise ValueError(f'Y must have shape {(X.shape[0], k)}, got {Y.shape}')
        if Y.dtype != np.float64:
            raise TypeError(f'Y must be float64, got {Y.dtype}')

def forward(params: Params, X: np.ndarray, hidden_activation: str='tanh') -> tuple[np.ndarray, dict]:
    _check_inputs(params, X)
    (g, _) = ACTIVATIONS[hidden_activation]
    A = X
    cache = {'A': [X], 'Z': []}
    n_layers = len(params)
    for (l, p) in enumerate(params):
        Z = A @ p['W'] + p['b']
        A = Z if l == n_layers - 1 else g(Z)
        cache['Z'].append(Z)
        cache['A'].append(A)
    return (A, cache)

def mse_loss(Yhat: np.ndarray, Y: np.ndarray) -> float:
    if Yhat.shape != Y.shape:
        raise ValueError(f'shape mismatch {Yhat.shape} vs {Y.shape}')
    return float(np.mean((Yhat - Y) ** 2))

def backward(params: Params, cache: dict, Y: np.ndarray, hidden_activation: str='tanh') -> Params:
    (_, g_grad) = ACTIVATIONS[hidden_activation]
    Yhat = cache['A'][-1]
    if Yhat.shape != Y.shape:
        raise ValueError(f'shape mismatch {Yhat.shape} vs {Y.shape}')
    (B, k) = Y.shape
    dZ = 2.0 * (Yhat - Y) / (B * k)
    grads: Params = [None] * len(params)
    for l in range(len(params) - 1, -1, -1):
        A_prev = cache['A'][l]
        grads[l] = {'W': A_prev.T @ dZ, 'b': dZ.sum(axis=0, keepdims=True)}
        if l > 0:
            dA_prev = dZ @ params[l]['W'].T
            dZ = dA_prev * g_grad(cache['Z'][l - 1], cache['A'][l])
    return grads

def loss_and_grads(params: Params, X: np.ndarray, Y: np.ndarray, hidden_activation: str='tanh') -> tuple[float, Params]:
    _check_inputs(params, X, Y)
    (Yhat, cache) = forward(params, X, hidden_activation)
    return (mse_loss(Yhat, Y), backward(params, cache, Y, hidden_activation))

def loss_only(params: Params, X: np.ndarray, Y: np.ndarray, hidden_activation: str='tanh') -> float:
    _check_inputs(params, X, Y)
    (Yhat, _) = forward(params, X, hidden_activation)
    return mse_loss(Yhat, Y)

def sgd_step(params: Params, grads: Params, lr: float) -> Params:
    """Plain SGD, theta <- theta - lr * grad. Returns new arrays; inputs are not modified."""
    return [{'W': p['W'] - lr * g['W'], 'b': p['b'] - lr * g['b']} for (p, g) in zip(params, grads)]
