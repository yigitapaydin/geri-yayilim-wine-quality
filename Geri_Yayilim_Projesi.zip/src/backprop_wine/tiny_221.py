"""Hand derivation of a 2-2-1 tanh network, written with scalars only (no NumPy matrix code).

This module is deliberately independent from manual_mlp.py: it uses Python floats and
math.tanh, loops over samples, and writes every partial derivative as its own formula.

Notation (same index convention as the matrix code, W[i][j] = weight from unit i to unit j):
    inputs        x_1, x_2                         (sample n: x_{n,1}, x_{n,2})
    hidden pre    z_j = x_1 W1[0][j] + x_2 W1[1][j] + b1[j]          j = 0, 1      (E1)
    hidden act    h_j = tanh(z_j)                                                (E2)
    output        yhat = h_0 W2[0] + h_1 W2[1] + b2                              (E3)
    loss          L = (1/B) sum_n (yhat_n - y_n)^2                               (E4)

Chain rule (per sample n, then summed over n):
    dL/dyhat_n    = 2 (yhat_n - y_n) / B                                         (E5)
    dL/dW2[j]     = sum_n dL/dyhat_n * h_{n,j}                                   (E6)
    dL/db2        = sum_n dL/dyhat_n                                             (E7)
    dL/dh_{n,j}   = dL/dyhat_n * W2[j]                                           (E8)
    dL/dz_{n,j}   = dL/dh_{n,j} * (1 - h_{n,j}^2)                                (E9)
    dL/dW1[i][j]  = sum_n dL/dz_{n,j} * x_{n,i}                                  (E10)
    dL/db1[j]     = sum_n dL/dz_{n,j}                                            (E11)
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field

@dataclass
class Tiny221:
    W1: list[list[float]]
    b1: list[float]
    W2: list[float]
    b2: float

    def to_matrix_params(self):
        """Convert to the list-of-dicts layout used by manual_mlp (imports NumPy only here)."""
        import numpy as np
        return [{'W': np.array(self.W1, dtype=np.float64), 'b': np.array([self.b1], dtype=np.float64)}, {'W': np.array([[self.W2[0]], [self.W2[1]]], dtype=np.float64), 'b': np.array([[self.b2]], dtype=np.float64)}]
EXAMPLE_PARAMS = Tiny221(W1=[[0.15, -0.25], [0.2, 0.3]], b1=[0.05, -0.1], W2=[0.4, -0.35], b2=0.1)
EXAMPLE_SINGLE_X = [[1.0, 0.5]]
EXAMPLE_SINGLE_Y = [0.8]
EXAMPLE_BATCH_X = [[1.0, 0.5], [-0.3, 0.8], [0.6, -1.2]]
EXAMPLE_BATCH_Y = [0.8, -0.2, 0.3]

def _forward_one(p: Tiny221, x: list[float]):
    z = [x[0] * p.W1[0][j] + x[1] * p.W1[1][j] + p.b1[j] for j in range(2)]
    h = [math.tanh(zj) for zj in z]
    yhat = h[0] * p.W2[0] + h[1] * p.W2[1] + p.b2
    return (z, h, yhat)

def loss(p: Tiny221, X: list[list[float]], Y: list[float]) -> float:
    B = len(X)
    total = 0.0
    for (x, y) in zip(X, Y):
        (_, _, yhat) = _forward_one(p, x)
        total += (yhat - y) ** 2
    return total / B

def grads(p: Tiny221, X: list[list[float]], Y: list[float]) -> dict[str, float]:
    """All 9 partial derivatives, named W1_ij, b1_j, W2_j, b2 (0-based indices)."""
    B = len(X)
    g = {f'W1_{i}{j}': 0.0 for i in range(2) for j in range(2)}
    g.update({'b1_0': 0.0, 'b1_1': 0.0, 'W2_0': 0.0, 'W2_1': 0.0, 'b2': 0.0})
    for (x, y) in zip(X, Y):
        (_, h, yhat) = _forward_one(p, x)
        d_yhat = 2.0 * (yhat - y) / B
        g['b2'] += d_yhat
        for j in range(2):
            g[f'W2_{j}'] += d_yhat * h[j]
            d_h = d_yhat * p.W2[j]
            d_z = d_h * (1.0 - h[j] ** 2)
            g[f'b1_{j}'] += d_z
            for i in range(2):
                g[f'W1_{i}{j}'] += d_z * x[i]
    return g

def scalar_grads_as_matrices(g: dict[str, float]):
    import numpy as np
    return [{'W': np.array([[g['W1_00'], g['W1_01']], [g['W1_10'], g['W1_11']]]), 'b': np.array([[g['b1_0'], g['b1_1']]])}, {'W': np.array([[g['W2_0']], [g['W2_1']]]), 'b': np.array([[g['b2']]])}]

@dataclass
class Node:
    name: str
    op: str
    parents: list[str]
    value: float = 0.0
    local: dict[str, float] = field(default_factory=dict)
    adjoint: float = 0.0

def _graph_spec():
    """Topologically ordered node list (name, op, parents)."""
    spec = [('x_0', 'input', []), ('x_1', 'input', []), ('y', 'input', []), ('W1_00', 'param', []), ('W1_01', 'param', []), ('W1_10', 'param', []), ('W1_11', 'param', []), ('b1_0', 'param', []), ('b1_1', 'param', []), ('W2_0', 'param', []), ('W2_1', 'param', []), ('b2', 'param', [])]
    for j in range(2):
        for i in range(2):
            spec.append((f'm_{i}{j}', 'mul', [f'x_{i}', f'W1_{i}{j}']))
        spec.append((f'z_{j}', 'add3', [f'm_0{j}', f'm_1{j}', f'b1_{j}']))
        spec.append((f'h_{j}', 'tanh', [f'z_{j}']))
        spec.append((f'p_{j}', 'mul', [f'h_{j}', f'W2_{j}']))
    spec.append(('yhat', 'add3', ['p_0', 'p_1', 'b2']))
    spec.append(('e', 'sub', ['yhat', 'y']))
    spec.append(('s', 'square', ['e']))
    spec.append(('L', 'mean_B1', ['s']))
    return spec

def graph_forward(p: Tiny221, x: list[float], y: float, perturb: dict[str, float] | None=None) -> dict[str, Node]:
    """Evaluate the graph. `perturb` adds a constant to a node's value right after it is computed
    (used to check every intermediate adjoint by finite differences)."""
    perturb = perturb or {}
    leaf = {'x_0': x[0], 'x_1': x[1], 'y': y, 'b2': p.b2, 'b1_0': p.b1[0], 'b1_1': p.b1[1], 'W2_0': p.W2[0], 'W2_1': p.W2[1]}
    for i in range(2):
        for j in range(2):
            leaf[f'W1_{i}{j}'] = p.W1[i][j]
    nodes: dict[str, Node] = {}
    for (name, op, parents) in _graph_spec():
        n = Node(name, op, parents)
        pv = [nodes[q].value for q in parents]
        if op in ('input', 'param'):
            n.value = leaf[name]
        elif op == 'mul':
            n.value = pv[0] * pv[1]
            n.local = {parents[0]: pv[1], parents[1]: pv[0]}
        elif op == 'add3':
            n.value = pv[0] + pv[1] + pv[2]
            n.local = {q: 1.0 for q in parents}
        elif op == 'tanh':
            n.value = math.tanh(pv[0])
            n.local = {parents[0]: 1.0 - n.value ** 2}
        elif op == 'sub':
            n.value = pv[0] - pv[1]
            n.local = {parents[0]: 1.0, parents[1]: -1.0}
        elif op == 'square':
            n.value = pv[0] ** 2
            n.local = {parents[0]: 2.0 * pv[0]}
        elif op == 'mean_B1':
            n.value = pv[0] / 1.0
            n.local = {parents[0]: 1.0}
        else:
            raise ValueError(op)
        n.value += perturb.get(name, 0.0)
        nodes[name] = n
    return nodes

def graph_backward(nodes: dict[str, Node]) -> dict[str, Node]:
    """Reverse sweep: bar(parent) += bar(child) * d(child)/d(parent)."""
    for n in nodes.values():
        n.adjoint = 0.0
    nodes['L'].adjoint = 1.0
    for name in reversed(list(nodes.keys())):
        n = nodes[name]
        for (parent, d_local) in n.local.items():
            nodes[parent].adjoint += n.adjoint * d_local
    return nodes

def graph_trace(p: Tiny221=EXAMPLE_PARAMS, x: list[float] | None=None, y: float | None=None) -> list[dict]:
    x = x if x is not None else EXAMPLE_SINGLE_X[0]
    y = y if y is not None else EXAMPLE_SINGLE_Y[0]
    nodes = graph_backward(graph_forward(p, x, y))
    return [{'node': n.name, 'op': n.op, 'parents': ','.join(n.parents), 'value': n.value, 'local_derivatives': ';'.join((f'd{n.name}/d{k}={v:.12g}' for (k, v) in n.local.items())), 'adjoint_dL_dnode': n.adjoint} for n in nodes.values()]
