"""Independent PyTorch autograd reference for the same MLP.

Only the parameter VALUES are taken from the NumPy side. The forward/backward computation is
done by torch.nn + autograd. Layout mapping:
    NumPy W_l (d_in x d_out)  ->  nn.Linear.weight (d_out x d_in) = W_l^T
    NumPy b_l (1 x d_out)     ->  nn.Linear.bias   (d_out,)
    loss: nn.MSELoss(reduction="mean")  (mean over all B*k elements, same as NumPy)
"""
from __future__ import annotations
import numpy as np
import torch
from torch import nn
TORCH_ACT = {'tanh': nn.Tanh, 'relu': nn.ReLU}

def build_model(params, hidden_activation: str='tanh', transpose_weights: bool=True) -> nn.Sequential:
    """`transpose_weights=False` exists only so tests can show that a layout bug is detected."""
    layers: list[nn.Module] = []
    for (l, p) in enumerate(params):
        (d_in, d_out) = p['W'].shape
        lin = nn.Linear(d_in, d_out, bias=True, dtype=torch.float64)
        with torch.no_grad():
            W = p['W'].T if transpose_weights else p['W']
            lin.weight.copy_(torch.from_numpy(np.ascontiguousarray(W)))
            lin.bias.copy_(torch.from_numpy(p['b'].reshape(-1).copy()))
        layers.append(lin)
        if l < len(params) - 1:
            layers.append(TORCH_ACT[hidden_activation]())
    return nn.Sequential(*layers)

def _linears(model: nn.Sequential) -> list[nn.Linear]:
    return [m for m in model if isinstance(m, nn.Linear)]

def model_to_params(model: nn.Sequential):
    return [{'W': lin.weight.detach().T.numpy().copy(), 'b': lin.bias.detach().reshape(1, -1).numpy().copy()} for lin in _linears(model)]

def _check_float64(X: np.ndarray, Y: np.ndarray) -> None:
    if X.dtype != np.float64 or Y.dtype != np.float64:
        raise TypeError(f'X and Y must be float64, got {X.dtype} and {Y.dtype}')

def loss_and_grads(params, X: np.ndarray, Y: np.ndarray, hidden_activation: str='tanh', transpose_weights: bool=True):
    _check_float64(X, Y)
    model = build_model(params, hidden_activation, transpose_weights)
    Xt = torch.from_numpy(X)
    Yt = torch.from_numpy(Y)
    loss = nn.MSELoss(reduction='mean')(model(Xt), Yt)
    loss.backward()
    grads = [{'W': lin.weight.grad.T.numpy().copy(), 'b': lin.bias.grad.reshape(1, -1).numpy().copy()} for lin in _linears(model)]
    return (float(loss.item()), grads)

def sgd_trajectory(params, X: np.ndarray, Y: np.ndarray, lr: float, steps: int, hidden_activation: str='tanh'):
    """Run `steps` full-batch SGD updates with torch.optim.SGD (no momentum, no weight decay).
    Returns (losses before each step, list of parameter snapshots after each step)."""
    _check_float64(X, Y)
    model = build_model(params, hidden_activation)
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.0, weight_decay=0.0)
    (Xt, Yt) = (torch.from_numpy(X), torch.from_numpy(Y))
    (losses, snapshots) = ([], [])
    for _ in range(steps):
        opt.zero_grad(set_to_none=True)
        loss = nn.MSELoss(reduction='mean')(model(Xt), Yt)
        loss.backward()
        opt.step()
        losses.append(float(loss.item()))
        snapshots.append(model_to_params(model))
    return (losses, snapshots)
