"""Backpropagation derivation and numerical gradient checks. Rows are samples; W is input × output; loss is mean squared error over all batch and output elements; computations use float64."""
