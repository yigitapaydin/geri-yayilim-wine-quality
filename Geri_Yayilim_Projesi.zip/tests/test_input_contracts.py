"""Reject invalid training shapes and incomplete or non-finite regression metrics."""
import math
import numpy as np
import pytest
from backprop_wine import train as T

def _small():
    rng = np.random.default_rng(0)
    return (rng.normal(size=(7, 2)), rng.normal(size=(7, 1)), rng.normal(size=(4, 2)), rng.normal(size=(4, 1)))
KW = dict(sizes=[2, 3, 1], hidden_activation='tanh', lr=0.05, batch_size=3, max_epochs=3, patience=10, min_delta=1e-06, seed=1)

@pytest.mark.parametrize('bad_yva', [lambda y: np.hstack([y, y + 10.0]), lambda y: y[:1], lambda y: y[:3]], ids=['width_4x2', 'single_row_1x1', 'rows_3x1'])
def test_train_mlp_rejects_wrong_validation_target(bad_yva):
    (Xtr, Ytr, Xva, Yva) = _small()
    with pytest.raises(ValueError, match='validation Y must have shape'):
        T.train_mlp(Xtr, Ytr, Xva, bad_yva(Yva), **KW)

def test_train_mlp_rejects_bad_train_shapes_and_columns():
    (Xtr, Ytr, Xva, Yva) = _small()
    with pytest.raises(ValueError, match='train Y'):
        T.train_mlp(Xtr, Ytr[:5], Xva, Yva, **KW)
    with pytest.raises(ValueError, match='columns'):
        T.train_mlp(Xtr[:, :1], Ytr, Xva[:, :1], Yva, **KW)
    with pytest.raises(ValueError, match='empty'):
        T.train_mlp(Xtr, Ytr, Xva[:0], Yva[:0], **KW)
    with pytest.raises(TypeError):
        T.train_mlp(Xtr, Ytr.ravel(), Xva, Yva, **KW)

@pytest.mark.parametrize('yt,yp,msg', [([0.0, 2.0, 4.0], [1.0], '3 values but y_pred has 1'), ([1.0], [0.0, 2.0, 4.0], '1 values but y_pred has 3'), ([0.0, 2.0, 4.0], [1.0, 2.0], '3 values but y_pred has 2'), ([0.0, 2.0, 4.0], [1.0, np.nan, 3.0], 'non-finite'), ([0.0, np.inf, 4.0], [1.0, 2.0, 3.0], 'non-finite'), ([], [], 'at least one'), (np.zeros((3, 2)), np.zeros((3, 2)), 'shape'), (np.zeros((1, 3)), np.zeros(3), 'shape'), (5.0, 5.0, 'shape')])
def test_regression_metrics_rejects(yt, yp, msg):
    with pytest.raises(ValueError, match=msg):
        T.regression_metrics(np.asarray(yt, dtype=float), np.asarray(yp, dtype=float))

def _row(seed, status, v, **extra):
    return {'aggregation_group': 'g', 'seed': seed, 'status': status, 'test_rmse': v, **extra}

@pytest.mark.parametrize('rows', [[_row(42, 'fitted', 1.0), _row(43, 'fitted', 3.0), _row(44, 'fitted', None)], [_row(42, 'fitted', 1.0), _row(43, 'fitted', 3.0), _row(44, 'fitted', math.nan)], [_row(42, 'fitted', 1.0), _row(43, 'fitted', 3.0), _row(44, 'fitted', math.inf)], [{'aggregation_group': 'g', 'seed': 42, 'status': 'fitted'}, _row(43, 'fitted', 3.0), _row(44, 'fitted', 5.0)], [_row(42, 'fitted', 1.0), _row(43, 'fitted', '0.7')], [_row(42, 'fitted', 1.0), _row(43, 'fitted', True)]], ids=['none', 'nan', 'inf', 'key_missing_in_first_row', 'string', 'bool'])
def test_aggregate_rejects_missing_or_nonfinite_completed_metric(rows):
    with pytest.raises(ValueError, match='missing or non-finite'):
        T.aggregate_runs(rows, {'fitted'}, prefixes=('test_',))

def test_aggregate_required_metrics_contract_and_failed_runs():
    rows = [_row(42, 'fitted', 1.0, test_mae=0.5), _row(43, 'fitted', 3.0, test_mae=0.7), _row(44, 'diverged', None)]
    out = T.aggregate_runs(rows, {'fitted'}, prefixes=('test_',))[0]
    assert (out['n_completed'], out['n_diverged'], out['test_rmse_mean']) == (2, 1, 2.0)
    assert out['aggregate_note'].startswith('PARTIAL')
    with pytest.raises(ValueError, match='test_r2'):
        T.aggregate_runs(rows, {'fitted'}, prefixes=('test_',), required_metrics=('test_rmse', 'test_r2'))
