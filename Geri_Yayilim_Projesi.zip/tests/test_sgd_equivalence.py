"""Compare synthetic SGD parameter updates with the independent automatic-differentiation reference."""
import numpy as np
import pytest
from backprop_wine import manual_mlp as mm
from backprop_wine import torch_reference as tr
from backprop_wine.gradcheck import compare_params
from backprop_wine.synthetic import case
from conftest import ARCHS, CFG, TOL

@pytest.mark.parametrize('arch', ARCHS, ids=[a['name'] for a in ARCHS])
def test_sgd_trajectory_matches_torch(arch):
    (params, X, Y) = case(arch, CFG)
    act = arch['hidden_activation']
    (lr, steps) = (CFG['sgd']['lr'], CFG['sgd']['steps'])
    tol = TOL['sgd_update_numpy_vs_torch']
    (t_losses, t_snaps) = tr.sgd_trajectory(params, X, Y, lr, steps, act)
    original = mm.copy_params(params)
    cur = params
    for s in range(steps):
        (loss, g) = mm.loss_and_grads(cur, X, Y, act)
        assert abs(loss - t_losses[s]) <= tol['atol'] + tol['rtol'] * abs(t_losses[s]), s
        cur = mm.sgd_step(cur, g, lr)
        res = compare_params(cur, t_snaps[s], tol['atol'], tol['rtol'])
        assert res['overall']['passed'], (s, res)
    np.testing.assert_array_equal(mm.flatten(params), mm.flatten(original))

def test_single_update_actually_moves_parameters():
    """Guard against a vacuous pass where both sides do nothing."""
    arch = ARCHS[0]
    (params, X, Y) = case(arch, CFG)
    (_, g) = mm.loss_and_grads(params, X, Y)
    new = mm.sgd_step(params, g, CFG['sgd']['lr'])
    delta = mm.flatten(new) - mm.flatten(params)
    assert np.abs(delta).max() > 0.0001
    np.testing.assert_allclose(delta, -CFG['sgd']['lr'] * mm.flatten(g), rtol=0, atol=1e-15)
