"""Official Wine Quality parsing, input-only groups, leakage-free split and train-only scaling."""
import csv
import json
import numpy as np
import pytest
from backprop_wine import data as D
RAW_OK = all(((D.RAW_DIR / f).exists() for f in ['winequality-red.csv', 'winequality-white.csv', 'winequality.names', 'manifest.json']))
need_raw = pytest.mark.skipif(not RAW_OK, reason='data/raw not present; run scripts/download_data.py')

@pytest.fixture(scope='module')
def red():
    return D.build_red()

def test_group_key_ignores_target_and_keeps_conflicting_labels_together():
    X = np.array([[1.0] * 11, [1.0] * 11, [2.0] * 11, [1.0] * 11])
    (gid, _) = D.assign_groups(X)
    assert gid.tolist() == [0, 0, 1, 0]
    st = D.duplicate_stats(X, np.array([5, 6, 5, 5]), gid)
    assert st['n_conflicting_label_groups'] == 1
    assert st['n_rows_in_conflicting_label_groups'] == 3
    assert st['n_full_row_duplicates_beyond_first'] == 1
    assert st['empirical_identical_input_mse_floor'] == pytest.approx(2 / 3 / 4, abs=1e-15)

def test_group_key_canonicalises_equal_numbers():
    assert D.group_key([float('7.40')] + [0.0] * 10) == D.group_key([7.4] + [0.0] * 10)
    with pytest.raises(ValueError):
        D.group_key([1.0] * 12)

def test_strict_parser_counts_bad_lines(tmp_path):
    hdr = ';'.join((f'"{c}"' for c in D.FEATURES + [D.TARGET]))
    good = ';'.join(['1'] * 11 + ['5'])
    p = tmp_path / 't.csv'
    p.write_text('\n'.join([hdr, good, ';'.join(['1'] * 11), ';'.join(['x'] * 12), ';'.join(['nan'] * 11 + ['5']), ';'.join(['1'] * 11 + ['5.5']), good]) + '\n')
    d = D.read_wine_csv(p)
    r = d['report']
    assert (r['n_rows_parsed'], r['n_wrong_field_count'], r['n_unparseable'], r['n_nan'], r['n_non_integer_target']) == (2, 1, 1, 1, 1)
    assert r['bad_lines'] == [3, 4, 5, 6]

@need_raw
def test_raw_hashes_match_manifest():
    m = json.loads((D.RAW_DIR / 'manifest.json').read_text())
    for mem in m['members']:
        assert D.sha256_file(D.RAW_DIR / mem['name']) == mem['sha256']
    assert D.sha256_file(D.RAW_DIR / 'wine+quality.zip') == next((step for step in m['provenance_chain'] if step['step'] == 'ZIP'))['sha256']
    assert {x['name'] for x in m['members']} == {'winequality-red.csv', 'winequality-white.csv', 'winequality.names'}

@need_raw
@pytest.mark.parametrize('subset,n_declared', [('red', 1599), ('white', 4898)])
def test_parse_is_complete_and_clean(subset, n_declared):
    d = D.read_wine_csv(D.RAW_DIR / D.SUBSET_FILES[subset])
    r = d['report']
    assert r['header_matches_expected']
    assert r['n_data_lines'] == r['n_rows_parsed'] == n_declared
    assert r['bad_lines'] == []
    assert np.isfinite(d['X']).all() and d['X'].shape == (n_declared, 11)

@need_raw
def test_every_row_in_exactly_one_split(red):
    s = red['split']
    assert len(s) == 1599 and set(s.tolist()) == {'train', 'validation', 'test'}
    assert sum(((s == k).sum() for k in ('train', 'validation', 'test'))) == 1599
    assert len(set(red['row_ids'])) == 1599

@need_raw
def test_zero_group_intersection(red):
    (g, s) = (red['group_id'], red['split'])
    (tr, va, te) = (set(g[s == k].tolist()) for k in ('train', 'validation', 'test'))
    assert not tr & va and (not tr & te) and (not va & te)

@need_raw
def test_identical_inputs_never_cross_splits(red):
    """Independent of group ids: check raw input vectors directly."""
    s = red['split']
    seen = {}
    for (x, k) in zip(red['X'], s):
        key = tuple(x.tolist())
        assert seen.setdefault(key, k) == k

@need_raw
def test_resplit_is_identical(red):
    again = D.build_red()
    assert np.array_equal(again['split'], red['split'])
    assert np.array_equal(again['group_id'], red['group_id'])

@need_raw
def test_saved_records_match_recomputation(red):
    with open(D.PROCESSED_DIR / 'red_rows.csv', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    assert [r['split'] for r in rows] == red['split'].tolist()
    assert [int(r['group_id']) for r in rows] == red['group_id'].tolist()
    out = D.load_processed()
    assert len(out['train']['y']) + len(out['validation']['y']) + len(out['test']['y']) == 1599

@need_raw
def test_scaler_statistics_come_from_train_only(red):
    tr = red['split'] == 'train'
    sc = red['scaler']
    assert sc.n_samples_seen_ == tr.sum()
    np.testing.assert_allclose(sc.mean_, red['X'][tr].mean(axis=0), rtol=1e-13, atol=0)
    np.testing.assert_allclose(sc.var_, red['X'][tr].var(axis=0, ddof=0), rtol=1e-12, atol=0)
    assert not np.allclose(sc.mean_, red['X'].mean(axis=0), rtol=1e-06, atol=0)
    saved = json.loads((D.PROCESSED_DIR / 'red_scaler_train.json').read_text())
    assert saved['n_samples_seen'] == int(tr.sum()) and saved['fit_split'] == 'train'
    np.testing.assert_allclose(saved['mean'], sc.mean_, rtol=1e-15, atol=0)

@need_raw
def test_changing_validation_and_test_values_does_not_change_the_fit(red):
    X2 = red['X'].copy()
    held_out = red['split'] != 'train'
    X2[held_out] = X2[held_out] * 7.0 + 1000.0
    sc2 = D.fit_scaler(X2[red['split'] == 'train'])
    np.testing.assert_array_equal(sc2.mean_, red['scaler'].mean_)
    np.testing.assert_array_equal(sc2.scale_, red['scaler'].scale_)

@need_raw
def test_validation_and_test_are_transform_only(red):
    sc = red['scaler']
    for k in ('validation', 'test'):
        Xk = red['X'][red['split'] == k]
        np.testing.assert_allclose(sc.transform(Xk), (Xk - sc.mean_) / sc.scale_, rtol=1e-13, atol=1e-13)
        assert sc.transform(Xk).shape[1] == 11

@need_raw
def test_every_quality_in_every_split(red):
    """Every observed quality value must occur in each split without splitting warnings."""
    assert red['split_warnings'] == []
    all_q = set(red['y'].tolist())
    for k in ('train', 'validation', 'test'):
        assert set(red['y'][red['split'] == k].tolist()) == all_q, k

@need_raw
def test_group_ids_do_not_depend_on_target(red):
    rng = np.random.default_rng(0)
    y_perm = rng.permutation(red['y'])
    (gid1, _) = D.assign_groups(red['X'])
    assert np.array_equal(gid1, red['group_id'])
    st = D.duplicate_stats(red['X'], y_perm, gid1)
    assert st['n_unique_input_vectors'] == red['group_id'].max() + 1
