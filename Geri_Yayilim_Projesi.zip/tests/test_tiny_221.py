"""Scalar hand derivation, matrix backpropagation and computational-graph adjoints."""
import math
import numpy as np
import pytest
from backprop_wine import manual_mlp as mm
from backprop_wine import tiny_221 as t
from backprop_wine.gradcheck import compare_params
from conftest import TOL

def test_forward_values_match_hand_arithmetic():
    (z, h, yhat) = t._forward_one(t.EXAMPLE_PARAMS, t.EXAMPLE_SINGLE_X[0])
    assert z[0] == pytest.approx(0.3, abs=1e-15)
    assert z[1] == pytest.approx(-0.2, abs=1e-15)
    expected_yhat = 0.4 * math.tanh(0.3) - 0.35 * math.tanh(-0.2) + 0.1
    assert yhat == pytest.approx(expected_yhat, abs=1e-15)

@pytest.mark.parametrize('X,Y', [(t.EXAMPLE_SINGLE_X, t.EXAMPLE_SINGLE_Y), (t.EXAMPLE_BATCH_X, t.EXAMPLE_BATCH_Y)], ids=['single', 'batch3'])
def test_scalar_derivation_matches_matrix_backprop(X, Y):
    tol = TOL['scalar_vs_matrix']
    p = t.EXAMPLE_PARAMS
    params = p.to_matrix_params()
    Xm = np.array(X, dtype=np.float64)
    Ym = np.array(Y, dtype=np.float64).reshape(-1, 1)
    (loss_m, g_m) = mm.loss_and_grads(params, Xm, Ym)
    assert loss_m == pytest.approx(t.loss(p, X, Y), abs=1e-15)
    res = compare_params(g_m, t.scalar_grads_as_matrices(t.grads(p, X, Y)), tol['atol'], tol['rtol'])
    assert res['overall']['passed'], res

def test_graph_leaf_adjoints_equal_scalar_gradients():
    nodes = t.graph_backward(t.graph_forward(t.EXAMPLE_PARAMS, t.EXAMPLE_SINGLE_X[0], t.EXAMPLE_SINGLE_Y[0]))
    g = t.grads(t.EXAMPLE_PARAMS, t.EXAMPLE_SINGLE_X, t.EXAMPLE_SINGLE_Y)
    for (name, value) in g.items():
        assert nodes[name].adjoint == pytest.approx(value, abs=1e-14), name
    loss = t.loss(t.EXAMPLE_PARAMS, t.EXAMPLE_SINGLE_X, t.EXAMPLE_SINGLE_Y)
    assert nodes['L'].value == pytest.approx(loss, abs=1e-15)

def test_every_intermediate_adjoint_by_node_perturbation():
    """bar(v) = dL/dv is checked for EVERY node (not only parameters) by perturbing v itself."""
    (p, x, y) = (t.EXAMPLE_PARAMS, t.EXAMPLE_SINGLE_X[0], t.EXAMPLE_SINGLE_Y[0])
    nodes = t.graph_backward(t.graph_forward(p, x, y))
    h = TOL['finite_difference_h1e-5']['h']
    (atol, rtol) = (TOL['finite_difference_h1e-5']['atol'], TOL['finite_difference_h1e-5']['rtol'])
    for (name, n) in nodes.items():
        lp = t.graph_forward(p, x, y, perturb={name: +h})['L'].value
        lm = t.graph_forward(p, x, y, perturb={name: -h})['L'].value
        fd = (lp - lm) / (2 * h)
        assert abs(n.adjoint - fd) <= atol + rtol * abs(fd), (name, n.adjoint, fd)
