"""Shared synthetic architectures and fixed numerical tolerances."""
import pytest
from backprop_wine.synthetic import load_config
CFG = load_config()
TOL = CFG['tolerances']
ARCHS = CFG['architectures']

@pytest.fixture(scope='session')
def cfg():
    return CFG
