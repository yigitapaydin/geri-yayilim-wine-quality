"""ReLU corner conventions and strict float64 array-shape contracts."""
import numpy as np
import pytest
from backprop_wine import manual_mlp as mm
from backprop_wine import torch_reference as tr
from backprop_wine.gradcheck import central_difference

def kink_case():
    """2-2-1 ReLU net and one sample x = 0, b1_0 = 0, so z_0 is EXACTLY 0 (on the kink)."""
    params = [{'W': np.array([[0.3, -0.2], [0.1, 0.4]]), 'b': np.array([[0.0, 0.25]])}, {'W': np.array([[0.7], [-0.5]]), 'b': np.array([[0.05]])}]
    X = np.array([[0.0, 0.0]])
    Y = np.array([[1.0]])
    return (params, X, Y)

def test_relu_kink_convention_and_finite_difference_disagreement():
    (params, X, Y) = kink_case()
    (_, cache) = mm.forward(params, X, 'relu')
    assert cache['Z'][0][0, 0] == 0.0
    (_, g_np) = mm.loss_and_grads(params, X, Y, 'relu')
    (_, g_t) = tr.loss_and_grads(params, X, Y, 'relu')
    assert g_np[0]['b'][0, 0] == 0.0
    assert g_t[0]['b'][0, 0] == 0.0
    h = 1e-05
    fd = central_difference(lambda p: mm.loss_only(p, X, Y, 'relu'), params, h)
    yhat = cache['A'][-1][0, 0]
    upstream = 2.0 * (yhat - Y[0, 0]) * params[1]['W'][0, 0]
    assert fd[0]['b'][0, 0] == pytest.approx(0.5 * upstream, rel=0.0001)
    assert abs(fd[0]['b'][0, 0] - g_np[0]['b'][0, 0]) > 0.1

    def L_at(delta):
        p = mm.copy_params(params)
        p[0]['b'][0, 0] += delta
        return mm.loss_only(p, X, Y, 'relu')
    right = (L_at(h) - L_at(0.0)) / h
    left = (L_at(0.0) - L_at(-h)) / h
    assert right == pytest.approx(upstream, rel=0.0001)
    assert left == 0.0

def test_y_shape_guard_prevents_broadcast_bug():
    params = mm.init_params([3, 4, 1], seed=0)
    X = np.zeros((5, 3))
    with pytest.raises(ValueError):
        mm.loss_and_grads(params, X, np.zeros(5))

@pytest.mark.parametrize('dtype', [np.int64, np.float32])
def test_non_float64_Y_rejected_numpy_and_torch(dtype):
    """Integer and float32 target arrays must be rejected by both implementations."""
    params = mm.init_params([3, 4, 1], seed=0)
    X = np.zeros((2, 3))
    Y = np.array([[5], [6]]).astype(dtype)
    with pytest.raises(TypeError):
        mm.loss_and_grads(params, X, Y)
    with pytest.raises(TypeError):
        mm.loss_only(params, X, Y)
    with pytest.raises(TypeError):
        tr.loss_and_grads(params, X, Y)
    with pytest.raises(TypeError):
        tr.sgd_trajectory(params, X, Y, lr=0.1, steps=1)

def test_float32_rejected():
    params = mm.init_params([3, 4, 1], seed=0)
    with pytest.raises(TypeError):
        mm.forward(params, np.zeros((2, 3), dtype=np.float32))

def test_init_is_seed_deterministic():
    a = mm.flatten(mm.init_params([11, 16, 8, 1], seed=42))
    b = mm.flatten(mm.init_params([11, 16, 8, 1], seed=42))
    c = mm.flatten(mm.init_params([11, 16, 8, 1], seed=43))
    np.testing.assert_array_equal(a, b)
    assert not np.array_equal(a, c)
