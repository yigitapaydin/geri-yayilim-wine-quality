"""Reject tampered data, schema, split and scaler records using private temporary copies."""
import csv
import hashlib
import json
import shutil
import pytest
from backprop_wine import data as D
RAW_FILES = ['winequality-red.csv', 'winequality-white.csv', 'winequality.names', 'manifest.json']
OK = all(((D.RAW_DIR / f).exists() for f in RAW_FILES)) and (D.PROCESSED_DIR / 'red_split_manifest.json').exists()
pytestmark = pytest.mark.skipif(not OK, reason='data/raw or data/processed missing')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

@pytest.fixture
def box(tmp_path):
    (raw, proc, cfgdir) = (tmp_path / 'raw', tmp_path / 'processed', tmp_path / 'configs')
    raw.mkdir()
    cfgdir.mkdir()
    for f in RAW_FILES:
        shutil.copy2(D.RAW_DIR / f, raw / f)
    shutil.copytree(D.PROCESSED_DIR, proc)
    shutil.copy2(D.CONFIG_PATH, cfgdir / D.CONFIG_PATH.name)
    return {'raw': raw, 'proc': proc, 'cfg': cfgdir / D.CONFIG_PATH.name}

def load(b):
    return D.load_processed(b['proc'], b['raw'], b['cfg'])

def fix_raw_manifest(b):
    """Attacker also rewrites the raw manifest hash of the red CSV."""
    p = b['raw'] / 'manifest.json'
    m = json.loads(p.read_text())
    for mem in m['members']:
        if mem['name'] == 'winequality-red.csv':
            mem['sha256'] = sha(b['raw'] / 'winequality-red.csv')
    p.write_text(json.dumps(m))

def fix_split_manifest(b, **extra):
    """Attacker also rewrites the split manifest (raw hash, record-file hashes, config hash)."""
    p = b['proc'] / 'red_split_manifest.json'
    m = json.loads(p.read_text())
    m['raw_red_sha256'] = sha(b['raw'] / 'winequality-red.csv')
    m['file_sha256'] = {f: sha(b['proc'] / f) for f in D.RECORD_FILES}
    m['config_sha256'] = sha(b['cfg'])
    m.update(extra)
    p.write_text(json.dumps(m))

def red_lines(b):
    return (b['raw'] / 'winequality-red.csv').read_text().split('\n')

def write_red(b, lines):
    (b['raw'] / 'winequality-red.csv').write_text('\n'.join(lines))

def first_heldout_row(b):
    with open(b['proc'] / 'red_rows.csv') as f:
        for r in csv.DictReader(f):
            if r['split'] != 'train':
                return r

def test_untampered_copy_loads(box):
    out = load(box)
    assert len(out['train']['y']) + len(out['validation']['y']) + len(out['test']['y']) == 1599
    assert out['config_version'] == D.load_config(box['cfg'])['version']

def _change_heldout_quality(b):
    r = first_heldout_row(b)
    ln = int(r['csv_line']) - 1
    lines = red_lines(b)
    fields = lines[ln].split(';')
    fields[11] = '3' if fields[11] != '3' else '4'
    lines[ln] = ';'.join(fields)
    write_red(b, lines)

def test_heldout_quality_change_rejected_by_raw_hash(box):
    _change_heldout_quality(box)
    with pytest.raises(D.DataIntegrityError, match='winequality-red.csv sha256'):
        load(box)

def test_heldout_quality_change_rejected_even_with_raw_manifest_rewritten(box):
    _change_heldout_quality(box)
    fix_raw_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='different red CSV'):
        load(box)

def test_heldout_quality_change_rejected_even_with_all_hashes_rewritten(box):
    _change_heldout_quality(box)
    fix_raw_manifest(box)
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='does not match recomputation'):
        load(box)

def test_swapped_header_rejected_even_with_all_hashes_rewritten(box):
    lines = red_lines(box)
    h = lines[0].split(';')
    (h[0], h[1]) = (h[1], h[0])
    lines[0] = ';'.join(h)
    write_red(box, lines)
    fix_raw_manifest(box)
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='header'):
        load(box)

@pytest.mark.parametrize('bad', ['nan', 'inf', 'x', '5.5'])
def test_bad_cell_rejected_not_dropped(box, bad):
    lines = red_lines(box)
    f = lines[10].split(';')
    if bad == '5.5':
        f[11] = bad
    else:
        f[3] = bad
    lines[10] = ';'.join(f)
    write_red(box, lines)
    fix_raw_manifest(box)
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='rejected lines'):
        load(box)

def test_wrong_field_count_rejected(box):
    lines = red_lines(box)
    lines[5] = ';'.join(lines[5].split(';')[:11])
    write_red(box, lines)
    fix_raw_manifest(box)
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='rejected lines'):
        load(box)

def test_blank_line_inside_file_rejected(box):
    lines = red_lines(box)
    lines.insert(50, '')
    write_red(box, lines)
    fix_raw_manifest(box)
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='blank lines'):
        load(box)

def test_deleted_row_rejected(box):
    lines = red_lines(box)
    del lines[100]
    write_red(box, lines)
    fix_raw_manifest(box)
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='rows'):
        load(box)

def _flip_one_split_cell(b):
    p = b['proc'] / 'red_rows.csv'
    with open(p) as f:
        rows = list(csv.DictReader(f))
    i = next((k for (k, r) in enumerate(rows) if r['split'] == 'train'))
    rows[i]['split'] = 'test'
    with open(p, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

def test_split_record_change_rejected_by_file_hash(box):
    _flip_one_split_cell(box)
    with pytest.raises(D.DataIntegrityError, match='red_rows.csv does not match its recorded SHA-256'):
        load(box)

def test_split_record_change_rejected_even_with_hash_rewritten(box):
    _flip_one_split_cell(box)
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='does not match recomputation'):
        load(box)

def test_scaler_change_rejected_even_with_hash_rewritten(box):
    p = box['proc'] / 'red_scaler_train.json'
    sc = json.loads(p.read_text())
    sc['mean'][0] += 1e-06
    p.write_text(json.dumps(sc))
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match="scaler 'mean'"):
        load(box)

def test_scaler_fitted_on_all_rows_rejected(box):
    from backprop_wine.data import fit_scaler, read_wine_csv_strict
    X = read_wine_csv_strict(box['raw'] / 'winequality-red.csv')['X']
    full = fit_scaler(X)
    p = box['proc'] / 'red_scaler_train.json'
    sc = json.loads(p.read_text())
    sc.update(mean=full.mean_.tolist(), scale=full.scale_.tolist(), var=full.var_.tolist(), n_samples_seen=int(full.n_samples_seen_))
    p.write_text(json.dumps(sc))
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='not the train-only fit'):
        load(box)

def test_config_change_rejected(box):
    c = json.loads(box['cfg'].read_text())
    c['split']['random_state'] = 43
    box['cfg'].write_text(json.dumps(c))
    with pytest.raises(D.DataIntegrityError, match='config file differs'):
        load(box)

def test_config_change_rejected_even_with_config_hash_rewritten(box):
    c = json.loads(box['cfg'].read_text())
    c['split']['random_state'] = 43
    box['cfg'].write_text(json.dumps(c))
    fix_split_manifest(box)
    with pytest.raises(D.DataIntegrityError, match='does not match recomputation'):
        load(box)

def test_real_raw_files_unchanged_after_negative_tests():
    m = json.loads((D.RAW_DIR / 'manifest.json').read_text())
    for mem in m['members']:
        assert sha(D.RAW_DIR / mem['name']) == mem['sha256']
    D.load_processed()

def _prov_box(tmp_path):
    raw = tmp_path / 'rawp'
    shutil.copytree(D.RAW_DIR, raw)
    return raw

def test_provenance_verifies_zip_and_card_snapshot():
    out = D.verify_provenance(D.RAW_DIR)
    assert out['zip_sha256'].startswith('3ed56667')

def test_provenance_rejects_tampered_zip(tmp_path):
    raw = _prov_box(tmp_path)
    p = raw / 'wine+quality.zip'
    p.write_bytes(p.read_bytes() + b'x')
    with pytest.raises(D.DataIntegrityError, match='provenance ZIP sha256'):
        D.verify_provenance(raw)

def test_provenance_rejects_missing_card_snapshot(tmp_path):
    raw = _prov_box(tmp_path)
    m = json.loads((raw / 'manifest.json').read_text())
    snap = [s for s in m['provenance_chain'] if s['step'] == 'UCI dataset card'][0]['checks']['snapshot_file']
    (raw / 'provenance' / snap.split('/')[-1]).unlink()
    with pytest.raises(D.DataIntegrityError, match='snapshot missing'):
        D.verify_provenance(raw)

def test_loader_returns_group_id_and_csv_line_aligned_with_records():
    out = D.load_processed()
    with open(D.PROCESSED_DIR / 'red_rows.csv') as f:
        rec = {r['row_id']: r for r in csv.DictReader(f)}
    for name in ('train', 'validation', 'test'):
        s = out[name]
        assert len(s['group_id']) == len(s['csv_line']) == len(s['row_ids'])
        for (rid, g, ln) in zip(s['row_ids'], s['group_id'], s['csv_line']):
            assert rec[rid]['split'] == name and int(rec[rid]['group_id']) == g and (int(rec[rid]['csv_line']) == ln)

def test_train_validation_phase_loader_contains_no_test_rows():
    out = D.load_processed(splits=('train', 'validation'))
    assert 'test' not in out and 'split' not in out
    with open(D.PROCESSED_DIR / 'red_rows.csv') as f:
        test_ids = {r['row_id'] for r in csv.DictReader(f) if r['split'] == 'test'}
    loaded = set(out['train']['row_ids']) | set(out['validation']['row_ids'])
    assert loaded.isdisjoint(test_ids) and len(loaded) == 1599 - len(test_ids)
    with pytest.raises(ValueError):
        D.load_processed(splits=('train', 'holdout'))
