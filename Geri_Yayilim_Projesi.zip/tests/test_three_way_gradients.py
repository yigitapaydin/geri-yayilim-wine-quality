"""Compare every analytic gradient with automatic differentiation and central differences."""
import numpy as np
import pytest
from backprop_wine import manual_mlp as mm
from backprop_wine import torch_reference as tr
from backprop_wine.gradcheck import central_difference, compare_params
from backprop_wine.synthetic import case
from conftest import ARCHS, CFG, TOL

@pytest.mark.parametrize('arch', ARCHS, ids=[a['name'] for a in ARCHS])
def test_numpy_matches_torch(arch):
    (params, X, Y) = case(arch, CFG)
    act = arch['hidden_activation']
    (loss_np, g_np) = mm.loss_and_grads(params, X, Y, act)
    (loss_t, g_t) = tr.loss_and_grads(params, X, Y, act)
    tol = TOL['numpy_vs_torch']
    assert abs(loss_np - loss_t) <= tol['atol'] + tol['rtol'] * abs(loss_t)
    res = compare_params(g_np, g_t, tol['atol'], tol['rtol'])
    assert res['overall']['passed'], res

@pytest.mark.parametrize('arch', ARCHS, ids=[a['name'] for a in ARCHS])
def test_numpy_matches_central_difference_all_parameters(arch):
    (params, X, Y) = case(arch, CFG)
    act = arch['hidden_activation']
    before = mm.flatten(params).copy()
    (_, g_np) = mm.loss_and_grads(params, X, Y, act)
    tol = TOL['finite_difference_h1e-5']
    (_, base_cache) = mm.forward(params, X, act)
    base_pattern = [Z > 0 for Z in base_cache['Z'][:-1]]
    pattern_changes = []

    def loss_fn(p):
        (Yhat, c) = mm.forward(p, X, act)
        if act == 'relu':
            pattern_changes.append(any((np.any((Z > 0) != bp) for (Z, bp) in zip(c['Z'][:-1], base_pattern))))
        return mm.mse_loss(Yhat, Y)
    fd = central_difference(loss_fn, params, tol['h'])
    if act == 'relu':
        assert len(pattern_changes) == 2 * before.size
        assert not any(pattern_changes), 'a finite-difference step crossed a ReLU kink'
    np.testing.assert_array_equal(mm.flatten(params), before)
    res = compare_params(g_np, fd, tol['atol'], tol['rtol'])
    assert res['overall']['passed'], res
    assert res['overall']['n'] == mm.flatten(params).size
