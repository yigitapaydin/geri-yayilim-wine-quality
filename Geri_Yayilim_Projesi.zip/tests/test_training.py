"""Synthetic mini-batching, SGD, early stopping, reproducibility and checkpoint contracts."""
import hashlib
import math
import numpy as np
import pytest
import torch
from backprop_wine import manual_mlp as mm
from backprop_wine import train as T
from backprop_wine.synthetic import make_batch

def _data(n_tr=45, n_va=13, seed=3):
    (Xtr, Ytr) = make_batch(4, 1, n_tr, seed)
    (Xva, Yva) = make_batch(4, 1, n_va, seed + 1)
    return (Xtr, Ytr, Xva, Yva)
KW = dict(sizes=[4, 5, 1], batch_size=8, max_epochs=6, patience=1000, min_delta=1e-06)

def test_checkpoint_is_absolute_best_while_patience_uses_min_delta():
    es = T.EarlyStopper(patience=2, min_delta=0.001)
    seq = [1.0, 0.9995, 0.999, 0.99899]
    outs = [es.update(e, v) for (e, v) in enumerate(seq)]
    assert [o[0] for o in outs] == [True, True, True, True]
    assert es.best_epoch == 3 and es.best_val == 0.99899
    assert [o[1] for o in outs] == [False, False, True, False]
    assert es.reference == 0.99899 and es.wait == 0
    es2 = T.EarlyStopper(patience=2, min_delta=0.001)
    for (e, v) in enumerate([1.0, 0.5, 0.6, 0.55]):
        (new_best, stop) = es2.update(e, v)
    assert es2.best_epoch == 1 and stop

def test_last_minibatch_is_kept_with_its_own_size():
    order = np.random.default_rng(0).permutation(1141)
    b = T.minibatch_indices(order, 32)
    assert len(b) == 36 and len(b[-1]) == 1141 - 35 * 32 == 21
    assert np.array_equal(np.sort(np.concatenate(b)), np.arange(1141))

def test_one_epoch_matches_torch_sgd_on_the_same_batches_including_short_last_batch():
    """Independent reference: torch MSELoss(mean) on each batch (last batch has 5 rows) + torch.optim.SGD."""
    (Xtr, Ytr, Xva, Yva) = _data()
    res = T.train_mlp(Xtr, Ytr, Xva, Yva, hidden_activation='tanh', lr=0.1, seed=11, **{**KW, 'max_epochs': 1})
    (init_seed, shuf) = T.rng_streams(11)
    params0 = mm.init_params(KW['sizes'], seed=init_seed)
    order = shuf.permutation(len(Xtr))
    from backprop_wine.torch_reference import build_model
    model = build_model(params0, 'tanh')
    opt = torch.optim.SGD(model.parameters(), lr=0.1)
    for idx in T.minibatch_indices(order, KW['batch_size']):
        opt.zero_grad()
        torch.nn.MSELoss(reduction='mean')(model(torch.from_numpy(Xtr[idx])), torch.from_numpy(Ytr[idx])).backward()
        opt.step()
    assert len(T.minibatch_indices(order, 8)[-1]) == 5
    from backprop_wine.torch_reference import model_to_params
    ref = model_to_params(model)
    yhat_ref = mm.forward(ref, Xtr, 'tanh')[0]
    assert res.history[1]['train_mse'] == pytest.approx(float(np.mean((yhat_ref - Ytr) ** 2)), rel=1e-12, abs=1e-14)

def test_epoch_metric_is_full_split_not_mean_of_batch_losses():
    (Xtr, Ytr, Xva, Yva) = _data()
    params = mm.init_params(KW['sizes'], seed=1)
    full = T._mse(params, Xtr, Ytr, 'tanh')
    batches = T.minibatch_indices(np.arange(len(Xtr)), 8)
    mean_of_batches = float(np.mean([T._mse(params, Xtr[i], Ytr[i], 'tanh') for i in batches]))
    assert full != pytest.approx(mean_of_batches, rel=1e-09)
    res = T.train_mlp(Xtr, Ytr, Xva, Yva, hidden_activation='tanh', lr=0.0, seed=0, **{**KW, 'max_epochs': 1})
    p0 = mm.init_params(KW['sizes'], seed=T.rng_streams(0)[0])
    assert res.history[0]['train_mse'] == T._mse(p0, Xtr, Ytr, 'tanh')

def test_activation_and_scaling_do_not_change_init_or_batch_order():
    (Xtr, Ytr, Xva, Yva) = _data()
    a = T.train_mlp(Xtr, Ytr, Xva, Yva, hidden_activation='tanh', lr=0.05, seed=42, **KW)
    b = T.train_mlp(Xtr, Ytr, Xva, Yva, hidden_activation='relu', lr=0.05, seed=42, **KW)
    c = T.train_mlp(Xtr * 50.0, Ytr, Xva * 50.0, Yva, hidden_activation='tanh', lr=0.05, seed=42, **KW)
    d = T.train_mlp(Xtr, Ytr, Xva, Yva, hidden_activation='tanh', lr=0.05, seed=43, **KW)
    assert a.init_digest == b.init_digest == c.init_digest != d.init_digest
    assert a.first_epoch_order_digest == b.first_epoch_order_digest == c.first_epoch_order_digest != d.first_epoch_order_digest
    assert a.batch_order_digest == b.batch_order_digest == c.batch_order_digest
    assert a.shuffle_state_end == b.shuffle_state_end

def test_rerun_identical_numeric_history_and_parameters():
    (Xtr, Ytr, Xva, Yva) = _data()
    a = T.train_mlp(Xtr, Ytr, Xva, Yva, hidden_activation='tanh', lr=0.05, seed=5, **KW)
    b = T.train_mlp(Xtr, Ytr, Xva, Yva, hidden_activation='tanh', lr=0.05, seed=5, **KW)
    strip = lambda h: [{k: v for (k, v) in r.items() if k != 'seconds'} for r in h]
    assert strip(a.history) == strip(b.history)
    assert all((np.array_equal(x['W'], y['W']) and np.array_equal(x['b'], y['b']) for (x, y) in zip(a.best_params, b.best_params)))

def test_divergence_is_recorded_not_hidden():
    (Xtr, Ytr, Xva, Yva) = _data()
    r = T.train_mlp(Xtr * 1000.0, Ytr * 1000.0, Xva * 1000.0, Yva * 1000.0, hidden_activation='relu', lr=10.0, seed=1, **{**KW, 'max_epochs': 50})
    assert r.status == 'diverged' and r.divergence['epoch'] >= 1
    assert r.best_params is not None and math.isfinite(r.best_val_mse)

def test_checkpoint_restore_reproduces_recorded_best_val_mse(tmp_path):
    (Xtr, Ytr, Xva, Yva) = _data()
    r = T.train_mlp(Xtr, Ytr, Xva, Yva, hidden_activation='tanh', lr=0.05, seed=9, **KW)
    h = T.save_checkpoint(tmp_path / 'ck.npz', r.best_params)
    assert h == hashlib.sha256((tmp_path / 'ck.npz').read_bytes()).hexdigest()
    back = T.load_checkpoint(tmp_path / 'ck.npz')
    assert T._mse(back, Xva, Yva, 'tanh') == r.best_val_mse
    assert r.history[r.best_epoch]['val_mse'] == r.best_val_mse

def test_frozen_snapshot_detects_change(tmp_path):
    from backprop_wine import frozen as F
    (tmp_path / 'x.txt').write_text('1')
    snap = F.snapshot(tmp_path, ['x.txt'])
    assert F.changed(tmp_path, snap) == {}
    (tmp_path / 'x.txt').write_text('2')
    assert list(F.changed(tmp_path, snap)) == ['x.txt']

def test_aggregation_keeps_main_three_seeds_together_and_excludes_rerun():
    """Aggregate the fixed three-seed group, exclude the ungrouped determinism run, and expose failed runs."""
    rows = [{'aggregation_group': 'mlp_main', 'used_in_selection': True, 'seed': 42, 'status': 'early_stopped', 'val_rmse': 0.6}, {'aggregation_group': 'mlp_main', 'used_in_selection': False, 'seed': 43, 'status': 'early_stopped', 'val_rmse': 0.62}, {'aggregation_group': 'mlp_main', 'used_in_selection': False, 'seed': 44, 'status': 'max_epochs', 'val_rmse': 0.64}, {'aggregation_group': None, 'seed': 42, 'status': 'early_stopped', 'val_rmse': 0.6}, {'aggregation_group': 'abl', 'seed': 42, 'status': 'diverged', 'val_rmse': 5.0}, {'aggregation_group': 'abl', 'seed': 43, 'status': 'early_stopped', 'val_rmse': 0.7}, {'aggregation_group': 'abl', 'seed': 44, 'status': 'early_stopped', 'val_rmse': 0.9}]
    out = {r['aggregation_group']: r for r in T.aggregate_runs(rows, {'early_stopped', 'max_epochs'})}
    assert set(out) == {'mlp_main', 'abl'}
    m = out['mlp_main']
    assert m['seeds'] == '42;43;44' and m['n_planned'] == m['n_completed'] == 3
    assert m['val_rmse_mean'] == pytest.approx(0.62) and m['val_rmse_std_ddof1'] == pytest.approx(0.02)
    a = out['abl']
    assert (a['n_planned'], a['n_completed'], a['n_diverged']) == (3, 2, 1)
    assert a['val_rmse_mean'] == pytest.approx(0.8) and a['aggregate_note'].startswith('PARTIAL')
    with pytest.raises(ValueError):
        T.aggregate_runs(rows + [{'aggregation_group': 'mlp_main', 'seed': 43, 'status': 'early_stopped', 'val_rmse': 1}], {'early_stopped'})

def test_sub_min_delta_improvement_moves_checkpoint_but_not_patience():
    """A new absolute best below the patience threshold updates the checkpoint without resetting its counter."""
    es = T.EarlyStopper(patience=60, min_delta=1e-06)
    es.update(0, 0.5)
    (new_best, _) = es.update(1, 0.5 - 5e-07)
    assert new_best and es.best_epoch == 1 and (es.wait == 1) and (es.reference == 0.5)

def test_activation_diagnostics_definitions():
    params = [{'W': np.array([[1.0, -1.0, 0.0]]), 'b': np.array([[0.0, 0.0, -1.0]])}, {'W': np.ones((3, 1)), 'b': np.zeros((1, 1))}]
    X = np.array([[4.0], [-0.5]])
    d = T.activation_diagnostics(params, X)
    assert d['tanh_saturation_frac'] == pytest.approx(2 / 6)
    assert d['relu_passive_frac'] == pytest.approx(4 / 6)
    assert d['relu_dead_unit_frac'] == pytest.approx(1 / 3)

def test_test_summary_aggregates_test_metrics_per_group():
    """Summarise synthetic per-run metrics using the mean and sample standard deviation over completed runs."""
    rows = [{'aggregation_group': 'g', 'seed': s, 'status': st, 'test_rmse': v, 'test_mae': v, 'test_r2': 0.1} for (s, st, v) in ((42, 'early_stopped', 0.6), (43, 'early_stopped', 0.7), (44, 'diverged', None))]
    out = T.aggregate_runs(rows, {'early_stopped'}, prefixes=('test_',))[0]
    assert (out['n_planned'], out['n_completed'], out['n_diverged']) == (3, 2, 1)
    assert out['test_rmse_mean'] == pytest.approx(0.65) and out['test_rmse_std_ddof1'] == pytest.approx(0.0707106781)

def test_as3_epoch0_is_measured_by_torch():
    """Measure initial reference metrics independently instead of copying the manual implementation."""
    (Xtr, Ytr, Xva, Yva) = _data()
    r = T.torch_trajectory_check(Xtr, Ytr, Xva, Yva, sizes=KW['sizes'], hidden_activation='tanh', lr=0.05, batch_size=8, n_epochs=3, seed=4, atol=1e-10, rtol=1e-08)
    assert [e['epoch'] for e in r['per_epoch']] == [0, 1, 2, 3]
    e0 = r['per_epoch'][0]
    assert e0['torch_val_mse'] == r['torch_val_mse_epoch0'] and e0['max_abs_param_diff'] == 0.0
    assert abs(e0['torch_val_mse'] - e0['numpy_val_mse']) <= 1e-10 + 1e-08 * abs(e0['torch_val_mse'])
    assert r['passed'] and len(r['torch_val_mse_by_epoch']) == 3
