"""Near-zero gradients and smooth-region versus kink-crossing finite-difference checks."""
import numpy as np
import pytest
from backprop_wine import manual_mlp as mm
from backprop_wine import tiny_221 as t
from backprop_wine import torch_reference as tr
from backprop_wine.gradcheck import central_difference, compare_params
from backprop_wine.synthetic import case
from conftest import ARCHS, CFG, TOL
FD = TOL['finite_difference_h1e-5']
BX = np.array(t.EXAMPLE_BATCH_X)
BY = np.array(t.EXAMPLE_BATCH_Y).reshape(-1, 1)

def test_saturated_tanh_near_zero_gradients_pass_mixed_but_not_pure_relative_tolerance():
    sat = t.Tiny221(W1=[[0.15, -0.25], [0.2, 0.3]], b1=[12.0, -0.1], W2=[0.4, -0.35], b2=0.1)
    params = sat.to_matrix_params()
    (_, g) = mm.loss_and_grads(params, BX, BY)
    (_, g_t) = tr.loss_and_grads(params, BX, BY)
    fd = central_difference(lambda p: mm.loss_only(p, BX, BY), params, FD['h'])
    tiny = np.abs(np.concatenate([g[0]['W'][:, 0], g[0]['b'][:, 0]]))
    assert tiny.max() < 1e-09 and tiny.min() > 0
    assert compare_params(g, fd, FD['atol'], FD['rtol'])['overall']['passed']
    assert compare_params(g, g_t, TOL['numpy_vs_torch']['atol'], TOL['numpy_vs_torch']['rtol'])['overall']['passed']
    assert not compare_params(g, fd, 0.0, FD['rtol'])['overall']['passed']

def test_dead_relu_unit_has_exactly_zero_gradients():
    dead = [{'W': np.array([[0.3, -0.2], [0.1, 0.4]]), 'b': np.array([[-5.0, 0.25]])}, {'W': np.array([[0.7], [-0.5]]), 'b': np.array([[0.05]])}]
    (_, cache) = mm.forward(dead, BX, 'relu')
    assert (cache['Z'][0][:, 0] < 0).all()
    (_, g) = mm.loss_and_grads(dead, BX, BY, 'relu')
    (_, g_t) = tr.loss_and_grads(dead, BX, BY, 'relu')
    fd = central_difference(lambda p: mm.loss_only(p, BX, BY, 'relu'), dead, FD['h'])
    for G in (g, g_t, fd):
        assert G[0]['W'][0, 0] == 0.0 and G[0]['W'][1, 0] == 0.0
        assert G[0]['b'][0, 0] == 0.0 and G[1]['W'][0, 0] == 0.0
    assert compare_params(g, fd, FD['atol'], FD['rtol'])['overall']['passed']
RELU = next((a for a in ARCHS if a['name'] == 'relu_smooth_region_11_16_8_1'))
TANH = next((a for a in ARCHS if a['name'] == 'deep_11_16_8_1_tanh'))

def _fd_error_and_flips(arch, h):
    (params, X, Y) = case(arch, CFG)
    act = arch['hidden_activation']
    (_, g) = mm.loss_and_grads(params, X, Y, act)
    (_, c) = mm.forward(params, X, act)
    base = [Z > 0 for Z in c['Z'][:-1]]
    flips = []

    def lf(p):
        (Yh, cc) = mm.forward(p, X, act)
        flips.append(any((np.any((Z > 0) != b) for (Z, b) in zip(cc['Z'][:-1], base))))
        return mm.mse_loss(Yh, Y)
    fd = central_difference(lf, params, h)
    return (float(np.abs(mm.flatten(fd) - mm.flatten(g)).max()), int(sum(flips)))

@pytest.mark.parametrize('h', [0.003, 0.001])
def test_relu_smooth_region_has_no_truncation_error(h):
    """With an unchanged ReLU pattern the loss is quadratic in each individual parameter, so central differences have zero truncation error. The tanh comparison retains its usual second-order truncation error."""
    (relu_err, relu_flips) = _fd_error_and_flips(RELU, h)
    (tanh_err, _) = _fd_error_and_flips(TANH, h)
    assert relu_flips == 0
    assert relu_err < 1e-10
    assert tanh_err > 1e-07
    assert tanh_err > 1000 * relu_err

def test_relu_large_step_crossing_a_kink_breaks_the_check():
    """At h = 1e-2 some +/-h evaluations change the ReLU pattern; the FD error then jumps far above tolerance.
    This is why the pattern precondition exists."""
    (err, flips) = _fd_error_and_flips(RELU, 0.01)
    assert flips > 0
    assert err > FD['atol']
