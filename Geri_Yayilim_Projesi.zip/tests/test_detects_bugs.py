"""Deliberately incorrect gradients must be rejected by independent numerical references."""
import numpy as np
import pytest
from backprop_wine import manual_mlp as mm
from backprop_wine import torch_reference as tr
from backprop_wine.gradcheck import central_difference, compare_params
from backprop_wine.synthetic import case, make_batch
from conftest import ARCHS, CFG, TOL
BUGS = ['bias_mean_instead_of_sum', 'missing_factor_2', 'sum_reduction_instead_of_mean', 'tanh_grad_uses_Z_not_A', 'missing_activation_grad_first_hidden', 'bias_grad_zero']

def buggy_backward(params, cache, Y, bug):
    Yhat = cache['A'][-1]
    (B, k) = Y.shape
    if bug == 'missing_factor_2':
        dZ = (Yhat - Y) / (B * k)
    elif bug == 'sum_reduction_instead_of_mean':
        dZ = 2.0 * (Yhat - Y)
    elif bug == 'divide_by_B_only':
        dZ = 2.0 * (Yhat - Y) / B
    else:
        dZ = 2.0 * (Yhat - Y) / (B * k)
    grads = [None] * len(params)
    for l in range(len(params) - 1, -1, -1):
        A_prev = cache['A'][l]
        if bug == 'bias_mean_instead_of_sum':
            db = dZ.mean(axis=0, keepdims=True)
        elif bug == 'bias_grad_zero':
            db = np.zeros((1, dZ.shape[1]))
        else:
            db = dZ.sum(axis=0, keepdims=True)
        grads[l] = {'W': A_prev.T @ dZ, 'b': db}
        if l > 0:
            dA = dZ @ params[l]['W'].T
            (Zp, Ap) = (cache['Z'][l - 1], cache['A'][l])
            if bug == 'tanh_grad_uses_Z_not_A':
                dZ = dA * (1.0 - Zp * Zp)
            elif bug == 'missing_activation_grad_first_hidden' and l == 1:
                dZ = dA
            else:
                dZ = dA * (1.0 - Ap * Ap)
    return grads
ARCH = next((a for a in ARCHS if a['name'] == 'deep_11_16_8_1_tanh'))

@pytest.mark.parametrize('bug', BUGS)
def test_bug_is_rejected_by_torch_and_finite_difference(bug):
    (params, X, Y) = case(ARCH, CFG)
    (_, cache) = mm.forward(params, X)
    g_bug = buggy_backward(params, cache, Y, bug)
    (_, g_t) = tr.loss_and_grads(params, X, Y)
    t1 = TOL['numpy_vs_torch']
    assert not compare_params(g_bug, g_t, t1['atol'], t1['rtol'])['overall']['passed'], bug
    t2 = TOL['finite_difference_h1e-5']
    fd = central_difference(lambda p: mm.loss_only(p, X, Y), params, t2['h'])
    assert not compare_params(g_bug, fd, t2['atol'], t2['rtol'])['overall']['passed'], bug

def test_reference_buggy_backward_without_bug_is_correct():
    """Sanity: the mutation harness itself, with no bug, reproduces the real backward."""
    (params, X, Y) = case(ARCH, CFG)
    (_, cache) = mm.forward(params, X)
    g_ok = buggy_backward(params, cache, Y, 'none')
    g = mm.backward(params, cache, Y)
    assert compare_params(g_ok, g, 0.0, 0.0)['overall']['passed']

def test_reduction_bug_is_INVISIBLE_with_batch_size_one():
    """Documented limitation: with B = k = 1, sum and mean reductions coincide.
    Hence the B > 1 cases in the config are necessary, not optional."""
    (params, X, Y) = case(next((a for a in ARCHS if a['name'] == 'single_sample_11_16_1_tanh')), CFG)
    (_, cache) = mm.forward(params, X)
    g_bug = buggy_backward(params, cache, Y, 'sum_reduction_instead_of_mean')
    (_, g_t) = tr.loss_and_grads(params, X, Y)
    t1 = TOL['numpy_vs_torch']
    assert compare_params(g_bug, g_t, t1['atol'], t1['rtol'])['overall']['passed']
MULTI = next((a for a in ARCHS if a['name'] == 'multi_output_5_4_3_2_tanh'))

def test_output_dim_reduction_bug_rejected_when_k_is_2():
    """Dividing by B instead of B*k must fail against both references for a two-output network."""
    (params, X, Y) = case(MULTI, CFG)
    assert Y.shape[1] == 2
    (_, cache) = mm.forward(params, X)
    g_bug = buggy_backward(params, cache, Y, 'divide_by_B_only')
    (_, g_t) = tr.loss_and_grads(params, X, Y)
    (t1, t2) = (TOL['numpy_vs_torch'], TOL['finite_difference_h1e-5'])
    assert not compare_params(g_bug, g_t, t1['atol'], t1['rtol'])['overall']['passed']
    fd = central_difference(lambda p: mm.loss_only(p, X, Y), params, t2['h'])
    assert not compare_params(g_bug, fd, t2['atol'], t2['rtol'])['overall']['passed']

def test_output_dim_reduction_bug_is_INVISIBLE_when_k_is_1():
    """Documented limitation, symmetric to the B = 1 case: with k = 1 the bug equals the correct gradient,
    so the multi-output configuration is necessary."""
    (params, X, Y) = case(ARCH, CFG)
    (_, cache) = mm.forward(params, X)
    g_bug = buggy_backward(params, cache, Y, 'divide_by_B_only')
    g = mm.backward(params, cache, Y)
    assert compare_params(g_bug, g, 0.0, 0.0)['overall']['passed']

def test_untransposed_torch_weights_are_detected_on_square_layers():
    """A 3-3-3-1 net has square hidden weights, so a missing transpose does not raise a shape error;
    it must still be caught numerically."""
    params = mm.init_params([3, 3, 3, 1], seed=CFG['seeds']['param_init'])
    (X, Y) = make_batch(3, 1, 5, CFG['seeds']['synthetic_data'])
    with pytest.raises(RuntimeError):
        tr.loss_and_grads(params, X, Y, transpose_weights=False)
    sq = [{'W': params[0]['W'].T.copy(), 'b': params[0]['b']}, {'W': params[1]['W'].T.copy(), 'b': params[1]['b']}, params[2]]
    (_, g_t_wrong) = tr.loss_and_grads(sq, X, Y)
    (_, g_np) = mm.loss_and_grads(params, X, Y)
    t1 = TOL['numpy_vs_torch']
    assert not compare_params(g_np, g_t_wrong, t1['atol'], t1['rtol'])['overall']['passed']
