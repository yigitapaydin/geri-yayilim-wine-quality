# Yöntem ve yeniden üretilebilirlik

## Küçük ağ ve türev denetimi

Öğretici ağ iki girdi, iki tanh gizli birim ve bir doğrusal çıkıştan oluşur. Dört girdi ağırlığı, iki gizli bias, iki çıkış ağırlığı ve bir çıkış biası vardır. Bu sentetik örnek bir Wine satırı değildir.

`tiny_221.py` skaler hesabı ve 26 düğümlü hesaplamalı çizgeyi; `manual_mlp.py` aynı işlemlerin matris biçimini uygular. Geri yayılım türevleri hesaplar, `sgd_step` ise parametreleri günceller. MSE, bütün örnek ve çıktı elemanları üzerinden ortalamadır; çıkış sinyali `2*(Yhat-Y)/(B*k)` olur. Ortak düğüme dönen farklı yol katkıları toplanır.

PyTorch, aynı modelin otomatik türev referansıdır. Merkezî sonlu fark ayrı bir sayısal kontroldür. ReLU’nun sıfır köşesinde klasik türev bulunmadığı için kodun seçtiği türevle merkezî farkın her zaman aynı olması beklenmez. Çok küçük sonlu fark adımlarında yuvarlama hatası büyüyebilir.

## Veri bölmesi

11 ölçümden oluşan aynı girdi vektörleri aynı gruba atanır. StratifiedGroupKFold yedi kat ve seed42 kullanır: kat0 test, kat1 doğrulama, kat2–6 eğitimdir. Yinelenen satırlar silinmez; yalnız bölmeler arası geçişleri önlenir. Grupların sayısı1359; eğitim/doğrulama/test grup sayıları970/195/194’tür.

Ölçekleyici yalnız1141eğitim satırından öğrenilir. `load_processed` kayıtlı satır/grup/bölme eşleşmelerini ve ölçekleyiciyi doğrular. Teslim yapılandırmasının hash’i güncel paket dosyasını bağlar; özgün yapılandırmanın hash’i splitmanifestte ayrıca tutulur. Bu metadata düzenlemesi yeni bir bilimsel ölçüm olarak sunulmaz.

## Eğitim ve değerlendirme

Başlangıç ve örnek sırası, her eğitim seed’inden türetilen iki ayrı rastgele sayı akışıdır. Başlatıcıya çocuk akışın kendisi verilmez; önce bu akıştan uint32 seed türetilir. Son mini-batch atılmaz ve kendi örnek sayısıyla ortalanır.

En küçük doğrulama kaybı ayrı olarak takip edilir. Sabır sayacı, referansa göre1e-6’dan büyük iyileşmede sıfırlanır;60dönemlik sabır dolduğunda durulur. Ufak bir mutlak rekor checkpoint’i değiştirip sabır sayacını sıfırlamayabilir. Veri bölmesi, normalizasyon veya model ayarları test sonucuna göre seçilmez.

Kayıtlı karşılaştırma MLP, eğitim ortalaması, Ridge, RBF-SVR ve rastgele ormanı içerir. Ana modelde tanh/ReLU ve ölçekli/ölçeksiz karşılaştırmaları ayrıca raporlanmıştır. Değişen seed’lerin standart sapması, farklı veri bölmelerinin belirsizliğini ölçmez; deterministik yöntemlerde sıfır sapma da kararlılık üstünlüğü değildir.

## Dosyaların kapsamı

`results/` özgün sayısal kayıtları, `models/` üç ana MLP’nin parametrelerini içerir. Bu dosyalar yeni bir çalıştırma gibi yeniden etiketlenmemiştir. Kaynak modüllerin hesaplama gövdeleri korunmuştur; teslim kopyasında iç süreç yorumları ve bağımlı dosya yolları sadeleştirilmiştir.

`train_models.py` yalnız yayımlanan son ayarlarla yeni modeller üretir. Akademik bölümdeki bütün seçim ızgaralarını, ablasyonları, donanım zamanlamasını ve PyTorch eğitim yörüngesi denetimini otomatik tekrar ettiği iddia edilmez. Bu ayrıntıların bilimsel açıklaması ve asıl sayısal kayıtları akademik bölümde bulunur.
