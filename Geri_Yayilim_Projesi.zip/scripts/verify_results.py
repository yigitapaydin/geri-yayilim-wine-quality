"""Verify file hashes and arithmetic over saved metrics; never fit or predict."""
from pathlib import Path
import csv
import hashlib
import math
import statistics

ROOT = Path(__file__).resolve().parents[1]


def main():
    count = 0
    for line in (ROOT / "SHA256SUMS.txt").read_text().splitlines():
        expected, relative = line.split("  ", 1)
        path = ROOT / relative
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f"Dosya özeti uyuşmuyor: {relative}")
        count += 1
    with (ROOT / "results/test/test_runs.csv").open(newline="") as stream:
        runs = list(csv.DictReader(stream))
    with (ROOT / "results/test/test_summary.csv").open(newline="") as stream:
        summaries = list(csv.DictReader(stream))
    controls = 0
    for summary in summaries:
        group = [row for row in runs if row["aggregation_group"] == summary["aggregation_group"]]
        assert len(group) == int(summary["n_completed"])
        for metric in ["test_rmse", "test_mae", "test_r2"]:
            values = [float(row[metric]) for row in group]
            mean = statistics.mean(values)
            sd = statistics.stdev(values) if len(values) > 1 else 0.0
            for suffix, actual in [("_mean", mean), ("_std_ddof1", sd)]:
                assert math.isclose(actual, float(summary[metric + suffix]), abs_tol=1e-12, rel_tol=1e-12)
                controls += 1
    print(f"Dosya bütünlüğü: {count}/{count}; kayıtlı metrik hesabı: {controls}/{controls}.")
    print("Model eğitimi, tahmin veya yeni test değerlendirmesi yapılmadı.")


if __name__ == "__main__":
    main()
