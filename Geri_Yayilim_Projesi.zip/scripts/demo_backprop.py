"""Print the scalar example and its nine gradients; no Wine model is trained."""
from backprop_wine import tiny_221 as tiny


def main():
    trace = tiny.graph_trace()
    print("2-2-1 öğretici ağ; gerçek Wine satırı değildir.")
    for row in trace:
        if row["node"] in {"z_0", "z_1", "h_0", "h_1", "yhat", "L"}:
            print(f"{row['node']:5s}: {float(row['value']):+.9f}")
    for name, value in tiny.grads(tiny.EXAMPLE_PARAMS, tiny.EXAMPLE_SINGLE_X, tiny.EXAMPLE_SINGLE_Y).items():
        print(f"dL/d{name:7s}: {value:+.9f}")


if __name__ == "__main__":
    main()
