"""Evaluate a separately trained experiment once, without changing packaged results."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import statistics
import joblib
import numpy as np
from backprop_wine import data, manual_mlp, train, frozen

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", type=Path, required=True)
    folder = parser.parse_args().experiment.resolve()
    if folder == ROOT or ROOT / "results" in folder.parents or folder == ROOT / "results":
        raise ValueError("Yeni deney dizini seçilmeli; kayıtlı sonuçlar yeniden değerlendirilmez.")
    manifest = json.loads((folder / "models.json").read_text())
    inputs = manifest.get("inputs_sha256")
    if not isinstance(inputs, dict) or set(inputs) != set(frozen.FROZEN_FILES) or not all(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) for value in inputs.values()):
        raise ValueError("Eğitim veri/kaynak özeti listesi eksik veya geçersiz.")
    if manifest["config_sha256"] != hashlib.sha256((ROOT / "configs/experiment.json").read_bytes()).hexdigest():
        raise ValueError("Eğitimden sonra yapılandırma değişmiş.")
    if frozen.changed(ROOT, manifest["inputs_sha256"]):
        raise ValueError("Eğitimde kaydedilen veri/kaynak dosyaları değişmiş.")
    for record in manifest["models"]:
        if Path(record["file"]).name != record["file"]:
            raise ValueError("Model yolu deney dizini içinde olmalı.")
        if hashlib.sha256((folder / record["file"]).read_bytes()).hexdigest() != record["sha256"]:
            raise ValueError("Kaydedilmiş model değişmiş.")
    # Exclusive marker prevents repeating test evaluation in the same experiment.
    with (folder / ".test_evaluation_started").open("x") as stream:
        stream.write("Test evaluation reserved.\n")
    test = data.load_processed(splits=("test",))["test"]
    if frozen.changed(ROOT, manifest["inputs_sha256"]):
        raise ValueError("Test verisi yüklenirken bir girdi dosyası değişmiş.")
    X, Y = test["X"], test["y"]
    runs = [{"method": "mean", "seed": seed,
        **train.regression_metrics(Y, np.full_like(Y, manifest["training_mean"]))} for seed in manifest["mean_seeds"]]
    for record in manifest["models"]:
        path = folder / record["file"]
        if record["method"] == "mlp":
            prediction = manual_mlp.forward(train.load_checkpoint(path), X, "tanh")[0]
        else:
            prediction = joblib.load(path).predict(X)
        runs.append({"method": record["method"], "seed": record["seed"], **train.regression_metrics(Y, prediction)})
    summary = []
    for method in sorted({row["method"] for row in runs}):
        selected = [row for row in runs if row["method"] == method]
        row = {"method": method, "n_runs": len(selected)}
        for metric in ["rmse", "mae", "r2"]:
            values = [record[metric] for record in selected]
            row[metric + "_mean"] = statistics.mean(values)
            row[metric + "_std"] = statistics.stdev(values) if len(values) > 1 else 0.0
        summary.append(row)
    (folder / "test_results.json").write_text(json.dumps({"runs": runs, "summary": summary}, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
