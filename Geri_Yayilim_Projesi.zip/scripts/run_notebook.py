"""Execute the notebook with this Python interpreter, writing a separate copy."""
from pathlib import Path
import argparse
import sys
import tempfile
import json
import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager
from jupyter_client.kernelspec import KernelSpecManager

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "build/backprop_wine.ipynb")
    target = parser.parse_args().output.resolve()
    if not target.is_relative_to(ROOT / "build") or target.suffix != ".ipynb":
        raise ValueError("Çıktı, build/ altında yeni bir .ipynb dosyası olmalı.")
    if target.exists():
        raise FileExistsError("Mevcut dosya üzerine yazılmaz; yeni bir çıktı seçin.")
    notebook = nbformat.read(ROOT / "notebooks/backprop_wine.ipynb", as_version=4)
    with tempfile.TemporaryDirectory() as temporary:
        directory = Path(temporary) / "local-python"
        directory.mkdir()
        (directory / "kernel.json").write_text(json.dumps({
            "argv": [sys.executable, "-m", "ipykernel_launcher", "-f", "{connection_file}"],
            "display_name": "Python", "language": "python"}))
        manager = KernelManager(kernel_name="local-python", kernel_spec_manager=KernelSpecManager(kernel_dirs=[temporary]))
        client = NotebookClient(notebook, km=manager, timeout=600, resources={"metadata": {"path": str(ROOT)}})
        try:
            client.execute()
        finally:
            if manager.has_kernel:
                manager.shutdown_kernel(now=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    nbformat.write(notebook, target)
    print(target)


if __name__ == "__main__":
    main()
