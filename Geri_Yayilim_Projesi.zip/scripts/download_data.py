"""Download the official UCI ZIP into a separate directory and validate its members."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
URL = "https://archive.ics.uci.edu/static/public/186/wine%2Bquality.zip"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--destination", type=Path, default=ROOT / "build/download")
    destination = parser.parse_args().destination.resolve()
    if destination.exists():
        raise FileExistsError("Yeni ve boş bir hedef dizin seçin; mevcut veriye yazılmaz.")
    with (ROOT / "data/raw/manifest.json").open() as stream:
        expected = {item["name"]: item["sha256"] for item in json.load(stream)["members"]}
    with urllib.request.urlopen(URL, timeout=60) as response:
        raw = response.read()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        if set(archive.namelist()) != set(expected):
            raise ValueError("UCI arşivindeki dosya listesi beklenen üç dosyayla uyuşmuyor.")
        contents = {name: archive.read(name) for name in expected}
    for name, value in contents.items():
        if hashlib.sha256(value).hexdigest() != expected[name]:
            raise ValueError(f"UCI dosyası kayıtlı veriyle aynı değil: {name}")
    destination.mkdir(parents=True)
    (destination / "wine+quality.zip").write_bytes(raw)
    for name, value in contents.items():
        (destination / name).write_bytes(value)
    print(f"Üç resmî veri dosyası doğrulandı: {destination}")


if __name__ == "__main__":
    main()
