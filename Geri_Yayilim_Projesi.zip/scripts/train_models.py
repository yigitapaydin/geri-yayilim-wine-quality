"""Train the published final configurations in a new, separate experiment directory.

Only train and validation splits are loaded. This script does not evaluate test data
and does not perform a new hyperparameter search.
"""
import os
for variable in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"]:
    os.environ[variable] = "1"

from pathlib import Path
import argparse
import csv
import hashlib
import json
import joblib
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.svm import SVR
from threadpoolctl import threadpool_limits
from backprop_wine import data, train, frozen

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.resolve()
    if output == ROOT or ROOT / "results" in output.parents or output == ROOT / "results":
        raise ValueError("Kayıtlı sonuçlar üzerine yazılmaz; experiments/ altında yeni bir dizin seçin.")
    output.mkdir(parents=True, exist_ok=False)
    cfg_bytes = (ROOT / "configs/experiment.json").read_bytes()
    cfg = json.loads(cfg_bytes)
    input_hashes = frozen.snapshot(ROOT)
    config_sha256 = hashlib.sha256(cfg_bytes).hexdigest()
    if input_hashes["configs/experiment.json"] != config_sha256:
        raise ValueError("Yapılandırma okunurken değişmiş.")
    if cfg["data"]["config_sha256"] != input_hashes["configs/data_split.json"] or cfg["data"]["split_manifest_sha256"] != input_hashes["data/processed/red_split_manifest.json"]:
        raise ValueError("Veri yapılandırması deneyde kayıtlı özetlerle uyuşmuyor.")
    partitions = data.load_processed(splits=("train", "validation"))
    X, Y = partitions["train"]["X"], partitions["train"]["y"].reshape(-1, 1)
    V, T = partitions["validation"]["X"], partitions["validation"]["y"].reshape(-1, 1)
    records = []
    with threadpool_limits(limits=1):
        for seed in cfg["seeds"]["training_seeds"]:
            m = cfg["mlp"]
            result = train.train_mlp(X, Y, V, T, sizes=m["sizes"], hidden_activation="tanh",
                lr=cfg["selected"]["learning_rate"], batch_size=m["batch_size"], max_epochs=m["max_epochs"],
                patience=m["early_stopping"]["patience"], min_delta=m["early_stopping"]["min_delta"], seed=seed)
            path = output / f"mlp_seed_{seed}.npz"
            if result.best_params is None or result.status not in cfg["completed_statuses"]:
                raise RuntimeError(f"MLP çalışması tamamlanmadı: seed={seed}, durum={result.status}")
            digest = train.save_checkpoint(path, result.best_params)
            with (output / f"history_seed_{seed}.csv").open("w", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=list(result.history[0]))
                writer.writeheader(); writer.writerows(result.history)
            records.append({"method": "mlp", "seed": seed, "file": path.name, "sha256": digest,
                "best_epoch": result.best_epoch, "best_validation_mse": result.best_val_mse})
            forest = RandomForestRegressor(random_state=seed, **cfg["selected"]["random_forest"])
            forest.fit(X, Y.ravel())
            model_path = output / f"forest_seed_{seed}.joblib"
            joblib.dump(forest, model_path)
            records.append({"method": "forest", "seed": seed, "file": model_path.name,
                "sha256": hashlib.sha256(model_path.read_bytes()).hexdigest()})
        for seed in cfg["seeds"]["training_seeds"]:
            for method, model in [("ridge", Ridge(**cfg["selected"]["ridge"])),
                                  ("svr", SVR(kernel="rbf", **cfg["selected"]["svr"]))]:
                model.fit(X, Y.ravel())
                path = output / f"{method}_seed_{seed}.joblib"; joblib.dump(model, path)
                records.append({"method": method, "seed": seed, "file": path.name,
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    if frozen.changed(ROOT, input_hashes):
        raise RuntimeError("Eğitim sırasında bir girdi dosyası değişti; deney tamamlanmış sayılmaz.")
    manifest = {"models": records, "training_mean": float(Y.mean()), "mean_seeds": cfg["seeds"]["training_seeds"],
                "config_sha256": config_sha256, "inputs_sha256": input_hashes}
    (output / "models.json").write_text(json.dumps(manifest, indent=2))
    print(f"Eğitim tamamlandı; test değerlendirilmedi: {output}")


if __name__ == "__main__":
    main()
